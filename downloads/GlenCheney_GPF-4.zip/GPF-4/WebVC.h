//
//  WebVC.h
//  GPF-4
//
//  Created by student on 1/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WebVC : UIViewController <UIWebViewDelegate, UIActionSheetDelegate>{
	IBOutlet UIToolbar *toolbar;
}

@property(nonatomic, copy) NSString *urlToOpen;
@property(nonatomic, retain) IBOutlet UIWebView *webView;
@property(nonatomic, retain) IBOutlet UIActivityIndicatorView *spinner;

-(id)initWithUrl:(NSString *)r_url;
-(void)loadPage;
-(IBAction)goBack;
-(IBAction)goForward;
-(IBAction)refresh;
-(void)openInSafari;
-(IBAction)webViewAction:(id)sender;

@end
