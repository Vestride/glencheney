//
//  RestaurantDetailTableVC.h
//  GPF-4
//
//  Created by Glen E Cheney on 1/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Restaurant.h"

@interface RestaurantDetailTableVC : UITableViewController {
	
}

@property(nonatomic, retain)Restaurant *restaurant;

-(void)addFavorite;
-(void)openURL;
-(void)callRestaurant;
-(void)zoomToAnnotation;

@end
