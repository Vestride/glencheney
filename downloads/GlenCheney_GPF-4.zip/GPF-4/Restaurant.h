//
//  Restaurant.h
//  GPF-1
//
//  Created by Glen E Cheney on 12/9/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@interface Restaurant : NSObject<MKAnnotation> {
	
}
+ (id)restaurant;
- (id)initWithID:(int)r_id
			name:(NSString *)r_name
		 address:(NSString *)r_address
			 url:(NSString *)r_url
		  rating:(float)r_rating
		location:(CLLocation *)r_location
	   plateName:(NSString *)r_plateName
	 phoneNumber:(NSString *)r_phoneNumber
	  lastUpdate:(NSDate *)r_lastUpdate;


@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;

@property (nonatomic, assign)float distance;

@property(nonatomic, assign)int restaurantID;
@property(nonatomic, copy)NSString *name;
@property(nonatomic, copy)NSString *address;
@property(nonatomic, copy)NSString *url;
@property(nonatomic, assign)float rating;
@property(nonatomic, retain)CLLocation *location;
@property(nonatomic, copy)NSString *plateName;
@property(nonatomic, copy)NSString *phoneNumber;
@property(nonatomic, retain)NSDate *lastUpdate;

@end
