//
//  MapVC.m
//  GPF-4
//
//  Created by Glen E Cheney on 1/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MapVC.h"
#import "Restaurant.h"

@implementation MapVC
@synthesize restaurants, mapView;

#pragma mark MKMapViewDelegate Methods
- (void)mapView:(MKMapView *)mv didUpdateUserLocation:(MKUserLocation *)userLocation{
	//NSLog(@"didUpdateUserLocation userLocation=%@",userLocation.location);
	
	MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance([userLocation coordinate], 20000, 20000);
	[mapView setRegion:region animated:YES];
	
	for(Restaurant *r in restaurants) {
		float miles = [self calcDistanceToRestaurant:r.location];
		r.distance = miles;
	}
	
	[self foundLocation];
}

// This delegate method is called once for every annotation that is created.
// If no view is returned by this method, then only the default pin is seen by the user
- (MKAnnotationView *)mapView:(MKMapView *)mv viewForAnnotation:(id <MKAnnotation>)annotation{
	MKAnnotationView *view = nil;
	//NSLog(@"viewForAnnotation called");
	if(annotation != mapView.userLocation) {
		// if it's NOT the user's current location pin, create the annotation
		Restaurant *restaurantAnnotation = (Restaurant*)annotation;
		// Look for an existing view to reuse
		view = [mv dequeueReusableAnnotationViewWithIdentifier:@"restaurantAnnotation"];
		// If an existing view is not found, create a new one
		if(view == nil) {
			view = [[[MKPinAnnotationView alloc] initWithAnnotation:restaurantAnnotation
													reuseIdentifier:@"restaurantAnnotation"] autorelease];
		}
		
		// Now we have a view for the annotation, so let's set some properties
		[(MKPinAnnotationView *)view setPinColor:MKPinAnnotationColorPurple];
		[(MKPinAnnotationView *)view setAnimatesDrop:YES];
		[view setCanShowCallout:YES];
		
		// Now create buttons for the annotation view
		// The 'tag' properties are set so that we can identify which button was tapped later
		UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
		leftButton.tag = 0;
		UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
		rightButton.tag = 1;
		
		// Add buttons to annotation view
		[view setLeftCalloutAccessoryView:leftButton];
		[view setRightCalloutAccessoryView:rightButton];
	}
	
	// send this annotation view back to MKMapView so it can add it to the pin 
	return view;
}

// This method is called when one of the two buttons added to the annotation view is tapped
- (void)mapView:(MKMapView *)mv annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control{
	Restaurant *restaurantAnnotation = (Restaurant *)[view annotation];
	switch ([control tag]) {
		case 0: // left button
		{
			NSURL *url = [NSURL URLWithString:restaurantAnnotation.url];
			[[UIApplication sharedApplication] openURL:url];
		}
			break;
			
		case 1: // right button
		{
			//NSString *latlong = [NSString stringWithFormat:@"%f,%f",restaurantAnnotation.coordinate.latitude,restaurantAnnotation.coordinate.longitude];
			//NSString *url = [NSString stringWithFormat: @"http://maps.google.com/maps?ll=%@", [latlong stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
			// build a maps url. This will launch the Maps app on the hardware, and the google maps website in the simulator
			CLLocationCoordinate2D coordinate = locationManager.location.coordinate; 
			NSString *url2 = [NSString stringWithFormat:@"http://maps.google.com/maps?saddr=%f,%f&daddr=%@",coordinate.latitude,coordinate.longitude,[restaurantAnnotation.address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
			
			[[UIApplication sharedApplication] openURL:[NSURL URLWithString:url2]];
		}
			break;
		default:
			NSLog(@"Should not be here in calloutAccessoryControlTapped, tag=%d!",[control tag]);
			break;
	}
	// Reference
	// http://developer.apple.com/library/ios/#featuredarticles/iPhoneURLScheme_Reference/Articles/MapLinks.html
	// http://stackoverflow.com/questions/30058/how-can-i-launch-the-google-maps-iphone-application-from-within-my-own-native-app
}
#pragma mark -
#pragma mark CLLocationManager methods
- (void)locationManager:(CLLocationManager *)manager
	didUpdateToLocation:(CLLocation *)newLocation
		   fromLocation:(CLLocation *)oldLocation {
	NSLog(@"%@", newLocation);
	NSTimeInterval t = [[newLocation timestamp] timeIntervalSinceNow];
	if (t < -180) {
		return;
	}
	
	MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance([newLocation coordinate], 20000, 20000);
	[mapView setRegion:region animated:YES];
	
	for(Restaurant *r in restaurants) {
		float miles = [self calcDistanceToRestaurant:r.location];
		r.distance = miles;
	}
	
	[self foundLocation];
}
#pragma mark -
#pragma mark Helper methods
- (float)calcDistanceToRestaurant:(CLLocation *)restaurant {
	CLLocationDistance distance = [restaurant distanceFromLocation:mapView.userLocation.location];
	float miles = distance/1609.344;
	//NSString *formattedNumber = [NSString stringWithFormat:@"%.02f", miles];
	return miles;
}

-(void)zoomOnRestaurant:(id<MKAnnotation>)annotation {
	MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(annotation.coordinate, 3000, 3000);
	[mapView setRegion:region animated:YES];
	[mapView selectAnnotation:annotation animated:YES];
}

- (IBAction)setMapType:(id)sender {
	switch (((UISegmentedControl *)sender).selectedSegmentIndex)
    {
        case 0:
        {
            mapView.mapType = MKMapTypeStandard;
            break;
        } 
        case 1:
        {
            mapView.mapType = MKMapTypeSatellite;
            break;
        }
		case 2: 
		{
			mapView.mapType = MKMapTypeHybrid;
			break;
		}
        default:
        {
            mapView.mapType = MKMapTypeStandard;
            break;
        } 
    }
	
}
- (IBAction)refreshLocation:(id)sender {
	[self findLocation];
}
- (void)findLocation {
	[locationManager startUpdatingLocation];
	[activityIndicator startAnimating];
}

- (void)foundLocation {
	[activityIndicator stopAnimating];
	[locationManager stopUpdatingLocation];
}


#pragma mark -

-(id)init {
	// Call the superclass's designated initializer
	[super initWithNibName:nil bundle:nil];
	
	// Get the tab bar item
	UITabBarItem *tbi = [self tabBarItem];
	
	// Give it a label
	tbi.title = @"Map";
	
	// Put that image on the tab bar item
	[tbi setImage:[UIImage imageNamed:@"103-map.png"]];
	
	return self;
}

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	mapView.delegate = self;
	
	locationManager = [[CLLocationManager alloc] init];
	locationManager.delegate = self;
	[locationManager setDistanceFilter:kCLDistanceFilterNone];
	[locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
	
	[mapView setShowsUserLocation:YES];
	
	for (Restaurant *r in restaurants) {
		[mapView addAnnotation:r];
		[r release];
	}
	
	[self findLocation];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[restaurants release];
	[locationManager release];
	[mapView release];
	[activityIndicator release];
    [super dealloc];
}


@end
