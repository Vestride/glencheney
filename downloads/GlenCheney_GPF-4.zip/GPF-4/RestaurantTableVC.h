//
//  RestaurantTableVC.h
//  GPF-4
//
//  Created by Glen E Cheney on 1/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@interface RestaurantTableVC : UITableViewController {
}

@property(nonatomic, retain)NSMutableArray *restaurants;

-(void)segmentedControlTapped:(id)sender;

@end
