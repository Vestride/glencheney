//
//  Restaurant.m
//  GPF-1
//
//  Created by Glen E Cheney on 12/9/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Restaurant.h"


@implementation Restaurant
@synthesize restaurantID, name, address, url, rating, location, plateName, phoneNumber, lastUpdate, coordinate, title, subtitle, distance;

+ (id)restaurant {
	Restaurant *restaurant = [[self alloc] init];
	return [restaurant autorelease];
}

- (id)initWithID:(int)r_id 
			name:(NSString *)r_name 
		 address:(NSString *)r_address 
			 url:(NSString *)r_url 
		  rating:(float)r_rating
		location:(CLLocation *)r_location
	   plateName:(NSString *)r_plateName
	 phoneNumber:(NSString *)r_phoneNumber
	  lastUpdate:(NSDate *)r_lastUpdate
{
	[super init];
	
	self.restaurantID = r_id;
	self.name = r_name;
	self.address = r_address;
	self.url = r_url;
	self.rating = r_rating;
	
	self.location = r_location;
	self.plateName = r_plateName;
	self.phoneNumber = r_phoneNumber;
	self.lastUpdate = r_lastUpdate;
	
	coordinate = r_location.coordinate;
	self.title = r_name;
	self.subtitle = r_plateName;
	
	self.distance = 0;
	
	return self;
}

- (id)init {
	return [self initWithID:-1 name:@"TBD" address:@"TBD" url:@"TBD" rating:-1 location:nil plateName:@"Unknown plate name" phoneNumber:@"Unknown phone number" lastUpdate:nil];
}

- (NSString *)description {
	return [NSString stringWithFormat:@"ResaurantID: %d, Name: %@, Rating: %f, Address: %@, URL: %@, location: %@, plateName: %@, phoneNumber: %@, lastUpdate: %@, distance: %d",
								   restaurantID, name, rating, address, url, location, plateName, phoneNumber, lastUpdate, distance];
}

- (void)setRestaurantID:(int)value {
	if(value > 0) {
		restaurantID = value;
	}
	else {
		NSLog(@"Bad value of %d in setRestaurantID - setting to 0", value);
		restaurantID = 0;
	}
}

- (void)setRating:(float)value {
	if(value >= 0.0 && value <= 5.0) {
		rating = value;
	}
	else {
		NSLog(@"Bad value of %f in setRating - setting to 0.0", value);
		rating = 0.0;
	}
}

- (void) dealloc {
	NSLog(@"dealloc called for id=%d",restaurantID);
	[lastUpdate release];
	[super dealloc];
}


@end
