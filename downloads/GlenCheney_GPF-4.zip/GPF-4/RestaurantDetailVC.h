//
//  RestaurantDetailVC.h
//  GPF-4
//
//  Created by Glen E Cheney on 1/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RestaurantDetailVC : UIViewController {
	IBOutlet UILabel *nameLabel;
	IBOutlet UIButton *urlButton;
	IBOutlet UIButton *addressButton;
	IBOutlet UIButton *phoneButton;
	IBOutlet UILabel *plateLabel;
}

@property(nonatomic, copy)NSString *r_name;
@property(nonatomic, copy)NSString *r_address;
@property(nonatomic, copy)NSString *r_url;
@property(nonatomic, copy)NSString *r_plateName;
@property(nonatomic, copy)NSString *r_phoneNumber;

-(IBAction)addFavorite:(id)sender;
-(IBAction)giveDirections:(id)sender;
-(IBAction)openURL:(id)sender;
-(IBAction)zoomOnRestaurant:(id)sender;
-(IBAction)callRestaurant:(id)sender;

@end
