//
//  RestaurantDetailVC.m
//  GPF-4
//
//  Created by Glen E Cheney on 1/20/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RestaurantDetailVC.h"


@implementation RestaurantDetailVC
@synthesize r_name, r_url, r_address, r_phoneNumber, r_plateName;

#pragma mark Helper methods
-(IBAction)addFavorite:(id)sender {
	NSLog(@"addFavorite");
}
-(IBAction)giveDirections:(id)sender {
	NSLog(@"giveDirections");
}
-(IBAction)openURL:(id)sender {
	NSLog(@"openURL");
}
-(IBAction)zoomOnRestaurant:(id)sender {
	NSLog(@"zoomOnRestaurant");
}
-(IBAction)callRestaurant:(id)sender {

}
#pragma mark -

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.navigationItem.title = r_name;
	[nameLabel setText:r_name];
	[plateLabel setText: r_plateName];
	[phoneButton setTitle:r_phoneNumber forState:UIControlStateNormal];
	[urlButton setTitle:r_url forState:UIControlStateNormal];
	[addressButton setTitle:r_address forState:UIControlStateNormal];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
