//
//  WebVC.m
//  GPF-4
//
//  Created by student on 1/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "WebVC.h"


@implementation WebVC
@synthesize webView, spinner, urlToOpen;

-(IBAction)loadPage {
	[spinner startAnimating];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	NSURL *url = [[NSURL alloc] initWithString:urlToOpen];
	NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
	[webView loadRequest:request];
	[request release];
	[url release];
}
-(IBAction)goBack {
	[webView goBack];
}
-(IBAction)goForward {
	[webView goForward];
}
- (IBAction)refresh {
	[webView reload];
}
- (void)openInSafari {
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlToOpen]];
}

// Action sheet delegate method.
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    // the user clicked one of the OK/Cancel buttons
    if (buttonIndex == 0)
    {
        [self openInSafari];
    }
}

- (IBAction)webViewAction:(id)sender
{
    // open a dialog with an OK and cancel button
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Hey how's it goin?" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Open in Safari",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleDefault;
    [actionSheet showFromToolbar:toolbar];
    [actionSheet release];
}

#pragma mark -
#pragma mark UIWebViewDelegate protocol methods
- (void)webViewDidStartLoad:(UIWebView *)webView {
	[spinner startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	[spinner stopAnimating];
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
	NSLog(@"didFailLoadWithError: %@", error);
	[spinner stopAnimating];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
	//Need to return YES or the webview won't load
	return YES;
}
#pragma mark -


// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

- (id)initWithUrl:(NSString *)r_url {
	self = [super initWithNibName:@"WebVC" bundle:nil];
    if (self) {
        // Custom initialization.
		urlToOpen = r_url;
    }
    return self;
	
}


- (void)viewDidLoad {
    [super viewDidLoad];
	webView.scalesPageToFit = YES;
	webView.delegate = self;
	//spinner.hideWhenStopped = YES;
}

- (void)viewWillAppear:(BOOL)animated {
	[self loadPage];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
