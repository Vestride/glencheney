//
//  FavoritesTableVC.h
//  GPF-4
//
//  Created by Glen E Cheney on 1/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FavoritesTableVC : UITableViewController {

}

@property(nonatomic, retain)NSMutableArray *restaurants;
@property(nonatomic, retain)NSMutableArray *favoriteRestaurants;

@end
