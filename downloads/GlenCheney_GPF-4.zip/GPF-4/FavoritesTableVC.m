//
//  FavoritesTableVC.m
//  GPF-4
//
//  Created by Glen E Cheney on 1/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FavoritesTableVC.h"
#import "RestaurantDetailTableVC.h"
#import "Restaurant.h"

@implementation FavoritesTableVC
@synthesize favoriteRestaurants, restaurants;


#pragma mark -
#pragma mark Initialization


- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization.
		UITabBarItem *tbi = [self tabBarItem];
		tbi.title = @"Favorites";
		tbi.image = [UIImage imageNamed:@"28-star.png"];
    }
    return self;
}



#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];
	self.navigationItem.title = @"Favorites";
	favoriteRestaurants = [[NSMutableArray alloc] init];
	
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
	
	[favoriteRestaurants removeAllObjects];
	NSMutableArray *array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"favorites"]];
	
	for (NSNumber *ID in array) {
		for (Restaurant *r in restaurants) {
			if ([ID intValue] == r.restaurantID) {
				[favoriteRestaurants addObject:r];
			}
		}
	}
	//[array release]; gets mad
	
	//Won't save order because the restaurants are always read in first!
	/*for (Restaurant *r in restaurants) {
		if ([array containsObject:[NSNumber numberWithInt:r.restaurantID]]) {
			[favoriteRestaurants addObject:r];
		}
	}*/
	
	
	[[self tableView] reloadData];
}

/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/

/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [favoriteRestaurants count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
	cell.textLabel.text = [[favoriteRestaurants objectAtIndex:indexPath.row] name];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {

		NSMutableArray *array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"favorites"]];
		for (int i = 0; i < [array count]; i++) {
			//If this restaurant's ID == the one in userDefaults, remove it
			if([[favoriteRestaurants objectAtIndex:indexPath.row] restaurantID] == [[array objectAtIndex:i] intValue]) {
				[array removeObjectAtIndex:i];
			}
		}
		[favoriteRestaurants removeObjectAtIndex:indexPath.row];
		[[NSUserDefaults standardUserDefaults] setObject:array forKey:@"favorites"];
		//[array release];
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}




// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
	//Update table view
	Restaurant *r = [[favoriteRestaurants objectAtIndex:[fromIndexPath row]] retain];
	[favoriteRestaurants removeObjectAtIndex:[fromIndexPath row]];
	[favoriteRestaurants insertObject:r atIndex:[toIndexPath row]];
	[r release];
	
	//Update UserDefaults
	NSMutableArray *array = [[NSMutableArray alloc] init];
	for(Restaurant *r in favoriteRestaurants) {
		[array addObject:[NSNumber numberWithInt:r.restaurantID]];
	}
	
	[[NSUserDefaults standardUserDefaults] setObject:array forKey:@"favorites"];
	[array release];
}



/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
    
    RestaurantDetailTableVC *detailViewController = [[RestaurantDetailTableVC alloc] initWithStyle:UITableViewStyleGrouped];
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	detailViewController.restaurant = [favoriteRestaurants objectAtIndex:indexPath.row];
	
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController release];
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
	[favoriteRestaurants release];
	[restaurants release];
    [super dealloc];
}


@end

