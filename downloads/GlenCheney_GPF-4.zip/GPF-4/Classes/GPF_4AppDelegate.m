//
//  GPF_4AppDelegate.m
//  GPF-4
//
//  Created by Glen E Cheney on 1/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GPF_4AppDelegate.h"
#import "MapVC.h"
#import "RestaurantTableVC.h"
#import "AboutVC.h"
#import "FavoritesTableVC.h"
#import "Restaurant.h"


@implementation GPF_4AppDelegate

@synthesize window, restaurants;

#pragma mark Helper methods
- (void)loadData {
	NSString *path = [[NSBundle mainBundle] pathForResource:@"data" ofType:@"plist"];
	restaurantDictionary = [[NSDictionary alloc] initWithContentsOfFile:path];

	NSArray *array = [[NSArray alloc] initWithArray:[restaurantDictionary objectForKey:@"restaurants"]];
	restaurants = [[NSMutableArray alloc] init];
	
	
	for(NSDictionary *dict in array) {
		//Get the location and make a new location object
		NSArray *splitArray = [[dict objectForKey:@"location"] componentsSeparatedByString:@","];
		float latitude = [[splitArray objectAtIndex:0] floatValue];
		float longitude = [[splitArray objectAtIndex:1] floatValue];
		CLLocation *location = [[CLLocation alloc] initWithLatitude:latitude longitude:longitude];
		
		//Instantiate new restaurant
		Restaurant *r = [[Restaurant alloc] initWithID:[[dict objectForKey:@"restaurantID"] intValue]
												  name:[dict objectForKey:@"name"]
											   address:[dict objectForKey:@"address"]
												   url:[dict objectForKey:@"url"]
												rating:[[dict objectForKey:@"rating"] floatValue]
											  location:location
											 plateName:[dict objectForKey:@"plateName"]
										   phoneNumber:[dict objectForKey:@"phoneNumber"]
											lastUpdate:[dict objectForKey:@"lastUpdate"]];
		
		[restaurants addObject:r];
		
		[location release];
		[r release];
	}
	[array release];
	
}

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    [self loadData];
		
    tabBarController = [[UITabBarController alloc] init];
	
	
	// Init view controllers
	MapVC *mapVC = [[MapVC alloc] init];
	RestaurantTableVC *restaurantsVC = [[RestaurantTableVC alloc] initWithStyle:UITableViewStylePlain];
	FavoritesTableVC *favoritesVC = [[FavoritesTableVC alloc] initWithStyle:UITableViewStylePlain];
	AboutVC *aboutVC = [[AboutVC alloc] initWithNibName:@"AboutVC" bundle:nil];
	
	//Pass around the restaurantDictionary
	mapVC.restaurants = restaurants;
	restaurantsVC.restaurants = restaurants;
	favoritesVC.restaurants = restaurants;
	
	UINavigationController *restaurantsNavigationController = [[UINavigationController alloc] initWithRootViewController:restaurantsVC];
	UINavigationController *favoritesNavigationController = [[UINavigationController alloc] initWithRootViewController:favoritesVC];
	
	// Add make an array of them
	NSArray *viewControllers = [NSArray arrayWithObjects:mapVC, restaurantsNavigationController, favoritesNavigationController, aboutVC, nil];
	
	// Release old pointers
	[mapVC release];
	[restaurantsVC release];
	[favoritesVC release];
	[aboutVC release];
	[restaurantsNavigationController release];
	[favoritesNavigationController release];
	
	// Add view controllers to the tab bar
	[tabBarController setViewControllers:viewControllers];
    
	[window addSubview:[tabBarController view]];
    [self.window makeKeyAndVisible];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
