//
//  GPF_4AppDelegate.h
//  GPF-4
//
//  Created by Glen E Cheney on 1/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface GPF_4AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	UITabBarController *tabBarController;
	NSMutableDictionary *restaurantDictionary;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain)NSMutableArray *restaurants;

-(void)loadData;

@end

