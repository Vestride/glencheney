//
//  MapVC.h
//  GPF-4
//
//  Created by Glen E Cheney on 1/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@interface MapVC : UIViewController <CLLocationManagerDelegate, MKMapViewDelegate> {
	CLLocationManager *locationManager;
	IBOutlet MKMapView *mapView;
	IBOutlet UIActivityIndicatorView *activityIndicator;
	NSMutableArray *restaurants;
}

@property(nonatomic, retain)NSMutableArray *restaurants;
@property(nonatomic, retain)MKMapView *mapView;

- (float)calcDistanceToRestaurant:(CLLocation *)restaurant;
- (IBAction)setMapType:(id)sender;
- (IBAction)refreshLocation:(id)sender;
- (void)findLocation;
- (void)foundLocation;
- (void)zoomOnRestaurant:(id<MKAnnotation>)annotation;

@end
