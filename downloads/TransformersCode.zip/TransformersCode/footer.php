<div id="footer">
        <p>
        	<span style="float: left;">
                <a href="<?php echo $path.$thisPage?>?change=decepticon"><img id="dsmall" onmouseover="changeThat(this)" onmouseout="revert(this);" src="<?php echo $path?>images/dsmall.jpg" alt="Decepticon" /></a>
                <a href="<?php echo $path.$thisPage?>?change=bumblebee"><img id="beesmall" onmouseover="changeThat(this)" onmouseout="revert(this);" src="<?php echo $path?>images/beesmall.jpg" alt="Bumblebee" /></a>
                <a href="<?php echo $path.$thisPage?>?change=optimus"><img id="opsmall" onmouseover="changeThat(this)" onmouseout="revert(this);" src="<?php echo $path?>images/opsmall.jpg" alt="Optimus Prime" /></a>
                <a href="<?php echo $path.$thisPage?>?change=fox"><img id="foxsmall" onmouseover="changeThat(this)" onmouseout="revert(this);" src="<?php echo $path?>images/foxsmall.jpg" alt="Megan Fox" /></a>
            </span>
            <span style="position: relative; top: 15px;">Tranformers 2: Revenge of the fallen</span>
        </p>
    </div>
    <!-- End footer -->
</div>
</body>
</html>