﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Customize
{
    public partial class Form1 : Form
    {
        public string language = "English";
        public string filename = "localize.txt";
        public string currentBackground = "";

        public Form1()
        {
            InitializeComponent();

            readFile(filename);
            readCustom("customize.txt");
            
        }

        public void readFile(string theFilename)
        {
            try
            {
                // CREATES AN INSTANCE OF STREAMREADER TO READ FROM THE LOCALIZE.TXT FILE.
                // THE USING STATEMENT CLOSES THE FILE WHEN DONE.
                using (StreamReader sr = new StreamReader(theFilename))
                {

                    string currentLanguage = "";
                    String line;

                    // WHILE THERE ARE STILL LINES IN THE TEXT
                    while ((line = sr.ReadLine()) != null)
                    {
                        // REMOVES ALL WHITE SPACE AND PUTS EACH WORD INTO AN ARRAY
                        line = line.Trim();
                        string[] words = line.Split(' ');

                        // IF THE LINE ISN'T BLANK
                        // BASED ON THE FIRST WORD ON THE LINE (IN THE LOCALIZE.TXT FILE),
                        // CHANGE ALL THE LABELS, BUTTONS, CHECKBOXES, ETC TO THE CURRENT LANGUAGE
                        if (words.Length >= 1)
                        {
                            switch (words[0])
                            {
                                case "English":
                                    currentLanguage = "English";
                                    break;
                                case "Spanish":
                                    currentLanguage = "Spanish";
                                    break;
                                case "German":
                                    currentLanguage = "German";
                                    break;
                                case "nameBox":
                                    if (language == currentLanguage)
                                    {
                                        nameBox.Text = words[1] + " " + words[2];
                                    }
                                    break;
                                case "emailBox":
                                    if (language == currentLanguage)
                                    {
                                        emailBox.Text = words[1] + " " + words[2];
                                    }
                                    break;
                                case "Gender1":
                                    if (language == currentLanguage)
                                    {
                                        Gender1.Text = words[1];
                                    }
                                    break;
                                case "Gender2":
                                    if (language == currentLanguage)
                                    {
                                        Gender2.Text = words[1];
                                    }
                                    break;
                                case "Interests1":
                                    if (language == currentLanguage)
                                    {
                                        Interests1.Text = words[1] + " " + words[2];
                                    }
                                    break;
                                case "Interests2":
                                    if (language == currentLanguage)
                                    {
                                        Interests2.Text = words[1];
                                    }
                                    break;
                                case "Interests3":
                                    if (language == currentLanguage)
                                    {
                                        Interests3.Text = words[1] + " " + words[2];
                                    }
                                    break;
                                case "Interests4":
                                    if (language == currentLanguage)
                                    {
                                        Interests4.Text = words[1] + " " + words[2];
                                    }
                                    break;
                                case "Language1":
                                    if (language == currentLanguage)
                                    {
                                        Language1.Text = words[1];
                                    }
                                    break;
                                case "Language2":
                                    if (language == currentLanguage)
                                    {
                                        Language2.Text = words[1];
                                    }
                                    break;
                                case "Language3":
                                    if (language == currentLanguage)
                                    {
                                        Language3.Text = words[1];
                                    }
                                    break;
                                case "Background1":
                                    if (language == currentLanguage)
                                    {
                                        Background1.Text = words[1];
                                    }
                                    break;
                                case "Background2":
                                    if (language == currentLanguage)
                                    {
                                        Background2.Text = words[1];
                                    }
                                    break;
                                case "Background3":
                                    if (language == currentLanguage)
                                    {
                                        Background3.Text = words[1];
                                    }
                                    break;
                                case "Background4":
                                    if (language == currentLanguage)
                                    {
                                        Background4.Text = words[1];
                                    }
                                    break;
                                case "label1":
                                    if (language == currentLanguage)
                                    {
                                        label1.Text = words[1];
                                    }
                                    break;
                                case "label2":
                                    if (language == currentLanguage)
                                    {
                                        label2.Text = words[1];
                                    }
                                    break;
                                case "label3":
                                    if (language == currentLanguage)
                                    {
                                        label3.Text = words[1];
                                    }
                                    break;
                                case "label4":
                                    if (language == currentLanguage)
                                    {
                                        label4.Text = words[1];
                                    }
                                    break;
                                case "save":
                                    if (language == currentLanguage)
                                    {
                                        save.Text = words[1];
                                    }
                                    break;
                                case "Form1":
                                    if (language == currentLanguage)
                                    {
                                        //It doesn't like Form1 :(
                                        //Form1.Text = words[1];
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                Console.WriteLine("Finally from readFile");
            }
        }
        public void readCustom(string theFilename)
        {
            try
            {
                // CREATES AN INSTANCE OF STREAMREADER TO READ FROM THE CUSTOMIZE.TXT FILE.
                // THE USING STATEMENT CLOSES THE FILE WHEN DONE.
                using (StreamReader sr = new StreamReader(theFilename))
                {
                    String line;
                    
                    // WHILE THE LINE ISN'T BLANK,
                    while ((line = sr.ReadLine()) != null)
                    {
                        // REMOVES WHITE SPACE AND PUTS WORDS ON THE SAME LINE INTO AN ARRAY
                        line = line.Trim();
                        string[] words = line.Split(' ');

                        // READS THE CUSTOMIZED CHECKBOXES, RADIO BUTTONS, TEXT BOXES, BACKGROUND COLOR, AND LANGUAGE.
                        // IF IT SAYS TRUE IN THE CUSTOMIZE.TXT FILE, MAKE IT CHECKED.
                        // IF IT SAYS "Language Spanish" IT CHANGES THE LANGUAGE VARIABLE TO SPANISH
                        // AND RE-READS THE FILE TO PUT IT INTO SPANISH.
                        if (words.Length >= 1)
                        {
                            switch (words[0])
                            {
                                case "Gender1":
                                    if (words[1] == "True")
                                    {
                                        Gender1.Checked = true;
                                    }
                                    break;
                                case "Gender2":
                                    if (words[1] == "True")
                                    {
                                        Gender2.Checked = true;
                                    }
                                    break;
                                case "Interests1":
                                    if (words[1] == "True")
                                    {
                                        Interests1.Checked = true;
                                    }
                                    break;
                                case "Interests2":
                                    if (words[1] == "True")
                                    {
                                        Interests2.Checked = true;
                                    }
                                    break;
                                case "Interests3":
                                    if (words[1] == "True")
                                    {
                                        Interests3.Checked = true;
                                    }
                                    break;
                                case "Interests4":
                                    if (words[1] == "True")
                                    {
                                        Interests4.Checked = true;
                                    }
                                    break;
                                case "Language":
                                    if (words[1] == "English")
                                    {
                                        language = "English";
                                        readFile(filename);
                                        break;
                                    }
                                    if (words[1] == "Spanish")
                                    {
                                        language = "Spanish";
                                        readFile(filename);
                                        break;
                                    }
                                    if (words[1] == "German")
                                    {
                                        language = "German";
                                        readFile(filename);
                                        break;
                                    }
                                    break;
                                case "Red":
                                    currentBackground = "Red";
                                    this.BackColor = System.Drawing.Color.Red;
                                    break;
                                case "WhiteSmoke":
                                    currentBackground = "WhiteSmoke";
                                    this.BackColor = System.Drawing.Color.WhiteSmoke;
                                    break;
                                case "Blue":
                                    currentBackground = "Blue";
                                    this.BackColor = System.Drawing.Color.Blue;
                                    break;
                                case "Green":
                                    currentBackground = "Green";
                                    this.BackColor = System.Drawing.Color.Green;
                                    break;
                                case "nameBox":
                                    nameBox.Text = words[1];
                                    break;
                                case "emailBox":
                                    emailBox.Text = words[1];
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                Console.WriteLine("Finally from readCustom");
            }
        }
        public void writeFile(string filename)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(filename))
                {

                    // WRITES OUT THE CUSTOMIZED SETTINGS FOR THE USER

                    sw.WriteLine("Language " + language);
                    sw.WriteLine("Gender1 " + Gender1.Checked);
                    sw.WriteLine("Gender2 " + Gender2.Checked);
                    sw.WriteLine("Interests1 " + Interests1.Checked);
                    sw.WriteLine("Interests2 " + Interests2.Checked);
                    sw.WriteLine("Interests3 " + Interests3.Checked);
                    sw.WriteLine("Interests4 " + Interests4.Checked);
                    sw.WriteLine(currentBackground);
                    sw.WriteLine("nameBox " + nameBox.Text);
                    sw.WriteLine("emailBox " + emailBox.Text);
                }
            }
            catch (Exception e)
            {
                // TELL THE USER WHAT HAPPENED
                Console.WriteLine("Could not read the file: ");
                Console.WriteLine(e.Message);
            }
        }

        private void save_Click(object sender, EventArgs e)
        {
            // WRITES OUT THE CUSTOMIZE FILE.
            writeFile("customize.txt");
        }

        private void Language2_Click(object sender, EventArgs e)
        {
            //Change the language to spanish and re-read the file
            language = "Spanish";
            readFile(filename);
        }

        private void Language1_Click(object sender, EventArgs e)
        {
            //Change the language to english and re-read the file
            language = "English";
            readFile(filename);
        }

        private void Background1_Click(object sender, EventArgs e)
        {
            //RED
            this.BackColor = System.Drawing.Color.Red;
            currentBackground = "Red";
        }

        private void Background2_Click(object sender, EventArgs e)
        {
            //BLUE
            this.BackColor = System.Drawing.Color.Blue;
            currentBackground = "Blue";
        }

        private void Background3_Click(object sender, EventArgs e)
        {
            //GREEN
            this.BackColor = System.Drawing.Color.Green;
            currentBackground = "Green";
        }

        private void Background4_Click(object sender, EventArgs e)
        {
            //DEFAULT
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            currentBackground = "WhiteSmoke";
        }

        private void Language3_Click(object sender, EventArgs e)
        {
            //Change the language to german and re-read the file
            language = "German";
            readFile(filename);
        }
    }
}
