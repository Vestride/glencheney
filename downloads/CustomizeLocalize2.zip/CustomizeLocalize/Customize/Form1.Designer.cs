﻿namespace Customize
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameBox = new System.Windows.Forms.TextBox();
            this.emailBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Gender1 = new System.Windows.Forms.RadioButton();
            this.Gender2 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.Interests1 = new System.Windows.Forms.CheckBox();
            this.Interests2 = new System.Windows.Forms.CheckBox();
            this.Interests3 = new System.Windows.Forms.CheckBox();
            this.Interests4 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Language1 = new System.Windows.Forms.Button();
            this.Language2 = new System.Windows.Forms.Button();
            this.Background1 = new System.Windows.Forms.Button();
            this.Background2 = new System.Windows.Forms.Button();
            this.Background3 = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.Background4 = new System.Windows.Forms.Button();
            this.Language3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(25, 161);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(100, 20);
            this.nameBox.TabIndex = 0;
            this.nameBox.Text = "First Name";
            // 
            // emailBox
            // 
            this.emailBox.Location = new System.Drawing.Point(25, 197);
            this.emailBox.Name = "emailBox";
            this.emailBox.Size = new System.Drawing.Size(100, 20);
            this.emailBox.TabIndex = 1;
            this.emailBox.Text = "Email address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 270);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Gender";
            // 
            // Gender1
            // 
            this.Gender1.AutoSize = true;
            this.Gender1.Location = new System.Drawing.Point(80, 258);
            this.Gender1.Name = "Gender1";
            this.Gender1.Size = new System.Drawing.Size(48, 17);
            this.Gender1.TabIndex = 3;
            this.Gender1.TabStop = true;
            this.Gender1.Text = "Male";
            this.Gender1.UseVisualStyleBackColor = true;
            // 
            // Gender2
            // 
            this.Gender2.AutoSize = true;
            this.Gender2.Location = new System.Drawing.Point(80, 282);
            this.Gender2.Name = "Gender2";
            this.Gender2.Size = new System.Drawing.Size(59, 17);
            this.Gender2.TabIndex = 4;
            this.Gender2.TabStop = true;
            this.Gender2.Text = "Female";
            this.Gender2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(257, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Interests";
            // 
            // Interests1
            // 
            this.Interests1.AutoSize = true;
            this.Interests1.Location = new System.Drawing.Point(260, 47);
            this.Interests1.Name = "Interests1";
            this.Interests1.Size = new System.Drawing.Size(89, 17);
            this.Interests1.TabIndex = 6;
            this.Interests1.Text = "Video Games";
            this.Interests1.UseVisualStyleBackColor = true;
            // 
            // Interests2
            // 
            this.Interests2.AutoSize = true;
            this.Interests2.Location = new System.Drawing.Point(260, 70);
            this.Interests2.Name = "Interests2";
            this.Interests2.Size = new System.Drawing.Size(54, 17);
            this.Interests2.TabIndex = 7;
            this.Interests2.Text = "Lifting";
            this.Interests2.UseVisualStyleBackColor = true;
            // 
            // Interests3
            // 
            this.Interests3.AutoSize = true;
            this.Interests3.Location = new System.Drawing.Point(260, 94);
            this.Interests3.Name = "Interests3";
            this.Interests3.Size = new System.Drawing.Size(126, 17);
            this.Interests3.TabIndex = 8;
            this.Interests3.Text = "Professional Napping";
            this.Interests3.UseVisualStyleBackColor = true;
            // 
            // Interests4
            // 
            this.Interests4.AutoSize = true;
            this.Interests4.Location = new System.Drawing.Point(260, 118);
            this.Interests4.Name = "Interests4";
            this.Interests4.Size = new System.Drawing.Size(94, 17);
            this.Interests4.TabIndex = 9;
            this.Interests4.Text = "Playing MMOs";
            this.Interests4.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(267, 155);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Background";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Language";
            // 
            // Language1
            // 
            this.Language1.Location = new System.Drawing.Point(21, 41);
            this.Language1.Name = "Language1";
            this.Language1.Size = new System.Drawing.Size(112, 23);
            this.Language1.TabIndex = 18;
            this.Language1.Text = "English";
            this.Language1.UseVisualStyleBackColor = true;
            this.Language1.Click += new System.EventHandler(this.Language1_Click);
            // 
            // Language2
            // 
            this.Language2.Location = new System.Drawing.Point(21, 70);
            this.Language2.Name = "Language2";
            this.Language2.Size = new System.Drawing.Size(112, 23);
            this.Language2.TabIndex = 19;
            this.Language2.Text = "Spanish";
            this.Language2.UseVisualStyleBackColor = true;
            this.Language2.Click += new System.EventHandler(this.Language2_Click);
            // 
            // Background1
            // 
            this.Background1.Location = new System.Drawing.Point(212, 181);
            this.Background1.Name = "Background1";
            this.Background1.Size = new System.Drawing.Size(88, 23);
            this.Background1.TabIndex = 20;
            this.Background1.Text = "Red";
            this.Background1.UseVisualStyleBackColor = true;
            this.Background1.Click += new System.EventHandler(this.Background1_Click);
            // 
            // Background2
            // 
            this.Background2.Location = new System.Drawing.Point(212, 210);
            this.Background2.Name = "Background2";
            this.Background2.Size = new System.Drawing.Size(88, 23);
            this.Background2.TabIndex = 21;
            this.Background2.Text = "Blue";
            this.Background2.UseVisualStyleBackColor = true;
            this.Background2.Click += new System.EventHandler(this.Background2_Click);
            // 
            // Background3
            // 
            this.Background3.Location = new System.Drawing.Point(306, 181);
            this.Background3.Name = "Background3";
            this.Background3.Size = new System.Drawing.Size(89, 23);
            this.Background3.TabIndex = 22;
            this.Background3.Text = "Green";
            this.Background3.UseVisualStyleBackColor = true;
            this.Background3.Click += new System.EventHandler(this.Background3_Click);
            // 
            // save
            // 
            this.save.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save.Location = new System.Drawing.Point(243, 265);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(121, 47);
            this.save.TabIndex = 23;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // Background4
            // 
            this.Background4.Location = new System.Drawing.Point(306, 210);
            this.Background4.Name = "Background4";
            this.Background4.Size = new System.Drawing.Size(89, 23);
            this.Background4.TabIndex = 24;
            this.Background4.Text = "Default";
            this.Background4.UseVisualStyleBackColor = true;
            this.Background4.Click += new System.EventHandler(this.Background4_Click);
            // 
            // Language3
            // 
            this.Language3.Location = new System.Drawing.Point(21, 99);
            this.Language3.Name = "Language3";
            this.Language3.Size = new System.Drawing.Size(112, 23);
            this.Language3.TabIndex = 25;
            this.Language3.Text = "German";
            this.Language3.UseVisualStyleBackColor = true;
            this.Language3.Click += new System.EventHandler(this.Language3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 330);
            this.Controls.Add(this.Language3);
            this.Controls.Add(this.Background4);
            this.Controls.Add(this.save);
            this.Controls.Add(this.Background3);
            this.Controls.Add(this.Background2);
            this.Controls.Add(this.Background1);
            this.Controls.Add(this.Language2);
            this.Controls.Add(this.Language1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Interests4);
            this.Controls.Add(this.Interests3);
            this.Controls.Add(this.Interests2);
            this.Controls.Add(this.Interests1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Gender2);
            this.Controls.Add(this.Gender1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.emailBox);
            this.Controls.Add(this.nameBox);
            this.Name = "Form1";
            this.Text = "Dreams";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox emailBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton Gender1;
        private System.Windows.Forms.RadioButton Gender2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox Interests1;
        private System.Windows.Forms.CheckBox Interests2;
        private System.Windows.Forms.CheckBox Interests3;
        private System.Windows.Forms.CheckBox Interests4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Language1;
        private System.Windows.Forms.Button Language2;
        private System.Windows.Forms.Button Background1;
        private System.Windows.Forms.Button Background2;
        private System.Windows.Forms.Button Background3;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Button Background4;
        private System.Windows.Forms.Button Language3;
    }
}

