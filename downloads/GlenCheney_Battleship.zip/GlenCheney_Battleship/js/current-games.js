function getCurrentGames() {
    ajaxCall("GET", {method: "currentGames", service: "game" , data: ""}, callBackGetCurrentGames);
}

function callBackGetCurrentGames(data) {
    var html = '<h3>Games in Progress</h3>';
    if(data != 'false') {
        for(var i in data) {
            html += '<div class="current_game">';
            var count = 0;
            var name1 = '';
            var name2 = '';
            var ptags = '';
            $.each(data[i], function(index, value){
                if(index == 'gameId') {
                    return 'continue';
                }
                ptags += '<p><strong>'+index+'\'s</strong> status: <br />'
                    + ' Aircraft Carrier ' + value.AircraftCarrier 
                    + ' <br />Battleship ' + value.Battleship
                    + ' <br />Cruiser ' + value.Cruiser
                    + ' <br />Submarine ' + value.Submarine
                    + ' <br />Destroyer ' + value.Destroyer
                    + '</p>';
                if (count == 0) {
                    name1 = index;
                } else if (count == 1) {
                    name2 = index;
                }
                count++;
            });
            html += '<h4>'+name1 + ' vs. ' + name2 + '</h4>';
            html += ptags;
            html += '</div>';
        }
    }
    
    $('#current_games').html(html);

    //Get an update every 15 seconds
    setTimeout('getCurrentGames()', 15000);
}