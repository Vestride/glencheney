-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 22, 2011 at 02:41 PM
-- Server version: 5.0.82
-- PHP Version: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gec5190`
--

-- --------------------------------------------------------

--
-- Table structure for table `b_challenges`
--

CREATE TABLE IF NOT EXISTS `b_challenges` (
  `challengeId` int(11) NOT NULL auto_increment,
  `challenger` int(10) NOT NULL,
  `challenged` int(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY  (`challengeId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `b_challenges`
--

INSERT INTO `b_challenges` (`challengeId`, `challenger`, `challenged`, `status`) VALUES
(84, 6, 10, 'ingame'),
(83, 6, 8, 'ingame');

-- --------------------------------------------------------

--
-- Table structure for table `b_gameInfo`
--

CREATE TABLE IF NOT EXISTS `b_gameInfo` (
  `id` smallint(6) NOT NULL auto_increment,
  `gameId` varchar(10) NOT NULL,
  `ships` int(11) NOT NULL,
  `guesses` int(11) NOT NULL,
  `aircraft_carrier_life` tinyint(4) NOT NULL default '5',
  `battleship_life` tinyint(4) NOT NULL default '4',
  `cruiser_life` tinyint(4) NOT NULL default '3',
  `submarine_life` tinyint(4) NOT NULL default '3',
  `destroyer_life` tinyint(4) NOT NULL default '2',
  `cell0_0` varchar(40) NOT NULL default '0_0',
  `cell0_1` varchar(40) NOT NULL default '0_0',
  `cell0_2` varchar(40) NOT NULL default '0_0',
  `cell0_3` varchar(40) NOT NULL default '0_0',
  `cell0_4` varchar(40) NOT NULL default '0_0',
  `cell0_5` varchar(40) NOT NULL default '0_0',
  `cell0_6` varchar(40) NOT NULL default '0_0',
  `cell0_7` varchar(40) NOT NULL default '0_0',
  `cell0_8` varchar(40) NOT NULL default '0_0',
  `cell0_9` varchar(40) NOT NULL default '0_0',
  `cell1_0` varchar(40) NOT NULL default '0_0',
  `cell1_1` varchar(40) NOT NULL default '0_0',
  `cell1_2` varchar(40) NOT NULL default '0_0',
  `cell1_3` varchar(40) NOT NULL default '0_0',
  `cell1_4` varchar(40) NOT NULL default '0_0',
  `cell1_5` varchar(40) NOT NULL default '0_0',
  `cell1_6` varchar(40) NOT NULL default '0_0',
  `cell1_7` varchar(40) NOT NULL default '0_0',
  `cell1_8` varchar(40) NOT NULL default '0_0',
  `cell1_9` varchar(40) NOT NULL default '0_0',
  `cell2_0` varchar(40) NOT NULL default '0_0',
  `cell2_1` varchar(40) NOT NULL default '0_0',
  `cell2_2` varchar(40) NOT NULL default '0_0',
  `cell2_3` varchar(40) NOT NULL default '0_0',
  `cell2_4` varchar(40) NOT NULL default '0_0',
  `cell2_5` varchar(40) NOT NULL default '0_0',
  `cell2_6` varchar(40) NOT NULL default '0_0',
  `cell2_7` varchar(40) NOT NULL default '0_0',
  `cell2_8` varchar(40) NOT NULL default '0_0',
  `cell2_9` varchar(40) NOT NULL default '0_0',
  `cell3_0` varchar(40) NOT NULL default '0_0',
  `cell3_1` varchar(40) NOT NULL default '0_0',
  `cell3_2` varchar(40) NOT NULL default '0_0',
  `cell3_3` varchar(40) NOT NULL default '0_0',
  `cell3_4` varchar(40) NOT NULL default '0_0',
  `cell3_5` varchar(40) NOT NULL default '0_0',
  `cell3_6` varchar(40) NOT NULL default '0_0',
  `cell3_7` varchar(40) NOT NULL default '0_0',
  `cell3_8` varchar(40) NOT NULL default '0_0',
  `cell3_9` varchar(40) NOT NULL default '0_0',
  `cell4_0` varchar(40) NOT NULL default '0_0',
  `cell4_1` varchar(40) NOT NULL default '0_0',
  `cell4_2` varchar(40) NOT NULL default '0_0',
  `cell4_3` varchar(40) NOT NULL default '0_0',
  `cell4_4` varchar(40) NOT NULL default '0_0',
  `cell4_5` varchar(40) NOT NULL default '0_0',
  `cell4_6` varchar(40) NOT NULL default '0_0',
  `cell4_7` varchar(40) NOT NULL default '0_0',
  `cell4_8` varchar(40) NOT NULL default '0_0',
  `cell4_9` varchar(40) NOT NULL default '0_0',
  `cell5_0` varchar(40) NOT NULL default '0_0',
  `cell5_1` varchar(40) NOT NULL default '0_0',
  `cell5_2` varchar(40) NOT NULL default '0_0',
  `cell5_3` varchar(40) NOT NULL default '0_0',
  `cell5_4` varchar(40) NOT NULL default '0_0',
  `cell5_5` varchar(40) NOT NULL default '0_0',
  `cell5_6` varchar(40) NOT NULL default '0_0',
  `cell5_7` varchar(40) NOT NULL default '0_0',
  `cell5_8` varchar(40) NOT NULL default '0_0',
  `cell5_9` varchar(40) NOT NULL default '0_0',
  `cell6_0` varchar(40) NOT NULL default '0_0',
  `cell6_1` varchar(40) NOT NULL default '0_0',
  `cell6_2` varchar(40) NOT NULL default '0_0',
  `cell6_3` varchar(40) NOT NULL default '0_0',
  `cell6_4` varchar(40) NOT NULL default '0_0',
  `cell6_5` varchar(40) NOT NULL default '0_0',
  `cell6_6` varchar(40) NOT NULL default '0_0',
  `cell6_7` varchar(40) NOT NULL default '0_0',
  `cell6_8` varchar(40) NOT NULL default '0_0',
  `cell6_9` varchar(40) NOT NULL default '0_0',
  `cell7_0` varchar(40) NOT NULL default '0_0',
  `cell7_1` varchar(40) NOT NULL default '0_0',
  `cell7_2` varchar(40) NOT NULL default '0_0',
  `cell7_3` varchar(40) NOT NULL default '0_0',
  `cell7_4` varchar(40) NOT NULL default '0_0',
  `cell7_5` varchar(40) NOT NULL default '0_0',
  `cell7_6` varchar(40) NOT NULL default '0_0',
  `cell7_7` varchar(40) NOT NULL default '0_0',
  `cell7_8` varchar(40) NOT NULL default '0_0',
  `cell7_9` varchar(40) NOT NULL default '0_0',
  `cell8_0` varchar(40) NOT NULL default '0_0',
  `cell8_1` varchar(40) NOT NULL default '0_0',
  `cell8_2` varchar(40) NOT NULL default '0_0',
  `cell8_3` varchar(40) NOT NULL default '0_0',
  `cell8_4` varchar(40) NOT NULL default '0_0',
  `cell8_5` varchar(40) NOT NULL default '0_0',
  `cell8_6` varchar(40) NOT NULL default '0_0',
  `cell8_7` varchar(40) NOT NULL default '0_0',
  `cell8_8` varchar(40) NOT NULL default '0_0',
  `cell8_9` varchar(40) NOT NULL default '0_0',
  `cell9_0` varchar(40) NOT NULL default '0_0',
  `cell9_1` varchar(40) NOT NULL default '0_0',
  `cell9_2` varchar(40) NOT NULL default '0_0',
  `cell9_3` varchar(40) NOT NULL default '0_0',
  `cell9_4` varchar(40) NOT NULL default '0_0',
  `cell9_5` varchar(40) NOT NULL default '0_0',
  `cell9_6` varchar(40) NOT NULL default '0_0',
  `cell9_7` varchar(40) NOT NULL default '0_0',
  `cell9_8` varchar(40) NOT NULL default '0_0',
  `cell9_9` varchar(40) NOT NULL default '0_0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=163 ;

--
-- Dumping data for table `b_gameInfo`
--

INSERT INTO `b_gameInfo` (`id`, `gameId`, `ships`, `guesses`, `aircraft_carrier_life`, `battleship_life`, `cruiser_life`, `submarine_life`, `destroyer_life`, `cell0_0`, `cell0_1`, `cell0_2`, `cell0_3`, `cell0_4`, `cell0_5`, `cell0_6`, `cell0_7`, `cell0_8`, `cell0_9`, `cell1_0`, `cell1_1`, `cell1_2`, `cell1_3`, `cell1_4`, `cell1_5`, `cell1_6`, `cell1_7`, `cell1_8`, `cell1_9`, `cell2_0`, `cell2_1`, `cell2_2`, `cell2_3`, `cell2_4`, `cell2_5`, `cell2_6`, `cell2_7`, `cell2_8`, `cell2_9`, `cell3_0`, `cell3_1`, `cell3_2`, `cell3_3`, `cell3_4`, `cell3_5`, `cell3_6`, `cell3_7`, `cell3_8`, `cell3_9`, `cell4_0`, `cell4_1`, `cell4_2`, `cell4_3`, `cell4_4`, `cell4_5`, `cell4_6`, `cell4_7`, `cell4_8`, `cell4_9`, `cell5_0`, `cell5_1`, `cell5_2`, `cell5_3`, `cell5_4`, `cell5_5`, `cell5_6`, `cell5_7`, `cell5_8`, `cell5_9`, `cell6_0`, `cell6_1`, `cell6_2`, `cell6_3`, `cell6_4`, `cell6_5`, `cell6_6`, `cell6_7`, `cell6_8`, `cell6_9`, `cell7_0`, `cell7_1`, `cell7_2`, `cell7_3`, `cell7_4`, `cell7_5`, `cell7_6`, `cell7_7`, `cell7_8`, `cell7_9`, `cell8_0`, `cell8_1`, `cell8_2`, `cell8_3`, `cell8_4`, `cell8_5`, `cell8_6`, `cell8_7`, `cell8_8`, `cell8_9`, `cell9_0`, `cell9_1`, `cell9_2`, `cell9_3`, `cell9_4`, `cell9_5`, `cell9_6`, `cell9_7`, `cell9_8`, `cell9_9`) VALUES
(162, '6|10', 10, 6, 5, 4, 0, 3, 2, '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '1_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_1', '1_1', '1_1', '1_1', '0_1', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0'),
(161, '6|10', 6, 10, 5, 4, 3, 0, 2, '0_0', '1_1', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '1_0', '0_0', '0_0', '1_1', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_1', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_1', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_1', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '1_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0'),
(160, '6|8', 6, 8, 5, 2, 3, 3, 1, '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_1', '1_1', '1_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_1', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_1', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_1', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '1_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0'),
(159, '6|8', 8, 6, 4, 4, 3, 0, 1, '0_0', '1_1', '0_0', '0_0', '0_0', '0_0', '0_0', '1_1', '1_0', '0_0', '0_0', '1_1', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_1', '0_0', '1_1', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '1_0', '1_0', '1_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0', '0_0');

-- --------------------------------------------------------

--
-- Table structure for table `b_games`
--

CREATE TABLE IF NOT EXISTS `b_games` (
  `gamesId` int(11) NOT NULL auto_increment,
  `gameId` varchar(10) NOT NULL,
  `player1` int(11) NOT NULL,
  `player2` int(11) NOT NULL,
  `turn` int(11) NOT NULL,
  PRIMARY KEY  (`gamesId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `b_games`
--

INSERT INTO `b_games` (`gamesId`, `gameId`, `player1`, `player2`, `turn`) VALUES
(63, '6|10', 6, 10, 10),
(62, '6|8', 6, 8, 8);

-- --------------------------------------------------------

--
-- Table structure for table `b_lobbychat`
--

CREATE TABLE IF NOT EXISTS `b_lobbychat` (
  `msgId` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `message` varchar(250) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`msgId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `b_lobbychat`
--


-- --------------------------------------------------------

--
-- Table structure for table `b_messages6_8`
--

CREATE TABLE IF NOT EXISTS `b_messages6_8` (
  `messageId` int(11) NOT NULL auto_increment,
  `createdBy` varchar(20) NOT NULL,
  `message` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY  (`messageId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `b_messages6_8`
--

INSERT INTO `b_messages6_8` (`messageId`, `createdBy`, `message`, `status`) VALUES
(1, 'fred', 'You sunk fred\'s Submarine', 'read');

-- --------------------------------------------------------

--
-- Table structure for table `b_messages6_10`
--

CREATE TABLE IF NOT EXISTS `b_messages6_10` (
  `messageId` int(11) NOT NULL auto_increment,
  `createdBy` varchar(20) NOT NULL,
  `message` varchar(100) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY  (`messageId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `b_messages6_10`
--

INSERT INTO `b_messages6_10` (`messageId`, `createdBy`, `message`, `status`) VALUES
(1, 'mike', 'You sunk mike\'s Submarine', 'read'),
(2, 'jake', 'You sunk jake\'s Cruiser', 'read');

-- --------------------------------------------------------

--
-- Table structure for table `b_privatechat6_8`
--

CREATE TABLE IF NOT EXISTS `b_privatechat6_8` (
  `msgId` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `message` varchar(250) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`msgId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `b_privatechat6_8`
--

INSERT INTO `b_privatechat6_8` (`msgId`, `username`, `message`, `timestamp`) VALUES
(1, 'fred', 'Opera', '2011-02-22 12:55:06');

-- --------------------------------------------------------

--
-- Table structure for table `b_privatechat6_10`
--

CREATE TABLE IF NOT EXISTS `b_privatechat6_10` (
  `msgId` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `message` varchar(250) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`msgId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `b_privatechat6_10`
--


-- --------------------------------------------------------

--
-- Table structure for table `b_ships6_8`
--

CREATE TABLE IF NOT EXISTS `b_ships6_8` (
  `entryId` int(11) NOT NULL auto_increment,
  `playerId` int(11) NOT NULL,
  `aircraft_carrier` varchar(10) NOT NULL,
  `battleship` varchar(10) NOT NULL,
  `cruiser` varchar(10) NOT NULL,
  `submarine` varchar(10) NOT NULL,
  `destroyer` varchar(10) NOT NULL,
  PRIMARY KEY  (`entryId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `b_ships6_8`
--

INSERT INTO `b_ships6_8` (`entryId`, `playerId`, `aircraft_carrier`, `battleship`, `cruiser`, `submarine`, `destroyer`) VALUES
(1, 8, '2_3|true', '2_7|true', '8_4|false', '0_1|true', '0_7|false'),
(2, 6, '2_3|true', '2_7|true', '8_4|false', '0_1|true', '0_7|false');

-- --------------------------------------------------------

--
-- Table structure for table `b_ships6_10`
--

CREATE TABLE IF NOT EXISTS `b_ships6_10` (
  `entryId` int(11) NOT NULL auto_increment,
  `playerId` int(11) NOT NULL,
  `aircraft_carrier` varchar(10) NOT NULL,
  `battleship` varchar(10) NOT NULL,
  `cruiser` varchar(10) NOT NULL,
  `submarine` varchar(10) NOT NULL,
  `destroyer` varchar(10) NOT NULL,
  PRIMARY KEY  (`entryId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `b_ships6_10`
--

INSERT INTO `b_ships6_10` (`entryId`, `playerId`, `aircraft_carrier`, `battleship`, `cruiser`, `submarine`, `destroyer`) VALUES
(1, 6, '2_3|true', '2_7|true', '8_4|false', '0_1|true', '0_7|false'),
(2, 10, '2_3|true', '2_7|true', '8_4|false', '0_1|true', '0_7|false');

-- --------------------------------------------------------

--
-- Table structure for table `b_users`
--

CREATE TABLE IF NOT EXISTS `b_users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `room` varchar(7) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `b_users`
--

INSERT INTO `b_users` (`id`, `username`, `password`, `email`, `room`) VALUES
(1, 'glen', 'c226bcbeea1369fe10f943fcc1abb3ac7d5f8286', 'glen@glencheney.com', NULL),
(2, 'dan', '2591e5f46f28d303f9dc027d475a5c60d8dea17a', 'dan@rit.edu', NULL),
(8, 'fred', '31017a722665e4afce586950f42944a6d331dabf', 'fred@rit.edu', '6|8'),
(6, 'mike', 'a17fed27eaa842282862ff7c1b9c8395a26ac320', 'mike@rit.edu', '6|10'),
(7, 'heather', 'd53652de63b26f2b99abfc5699fac10f3f95e1f7', 'hle1167@gmail.com', NULL),
(9, 'alli', '16a137ab55cb338639b7f454a609edc98b33aac5', 'anc1726@rit.edu', NULL),
(10, 'jake', 'c8d99c2f7cd5f432c163abcd422672b9f77550bb', 'jake.likewise@gmail.com', '6|10');
