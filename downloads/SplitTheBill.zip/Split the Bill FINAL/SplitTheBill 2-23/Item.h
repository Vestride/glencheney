//
//  Item.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Person;

@interface Item : NSObject {

}

@property(nonatomic, copy)NSString *name;
@property(nonatomic, assign)float price;
@property(nonatomic, retain)Person *owner;

- (id)initWithName:(NSString *)itemName price:(float)itemPrice owner:(Person *)itemOwner;

@end
