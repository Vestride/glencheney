//
//  GroupItem.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GroupItem.h"


@implementation GroupItem
@synthesize name, price, owners;

- (id)initWithName:(NSString *)itemName price:(float)itemPrice owners:(NSMutableArray *)itemOwners {
	self = [super init];
	
	self.name = itemName;
	self.price = itemPrice;
	self.owners = itemOwners;
	
	return self;
}

- (NSString *) description {
	return [NSString stringWithFormat:@"Name: %@, Price: %f, Owners:%@", name, price, owners];
}

-(void)dealloc {
	[name release];
	[owners release];
	[super dealloc];
}

@end
