//
//  Order.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Order.h"


@implementation Order
@synthesize people, groupItems, subtotal, total, tax, tip, timestamp;

- (id)init {
	self = [super init];
	if(!self) return nil;
	
	//http://iphonedevelopertips.com/cocoa/date-formatter-examples.html
	//02/23/2011 08:29PM
	NSDate *today = [NSDate date];
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"MM/dd/yyyy hh"];
	self.timestamp = [dateFormat stringFromDate:today];
	NSLog(@"date: %@", timestamp);
	[dateFormat release];
	
	self.people = [[NSMutableArray alloc] init];
	self.groupItems = [[NSMutableArray alloc] init];
	self.subtotal = 0;
	self.total = 0;
	self.tax = 0;
	self.tip = 0;
	
	return self;
}

- (NSString *)description {
	NSString *returnStr = [NSString stringWithFormat:@"People: %@, Group Items: %@", people, groupItems];
	return returnStr;
}
  
- (void) dealloc
{
	[people release];
	[groupItems release];
	[super dealloc];
}


@end
