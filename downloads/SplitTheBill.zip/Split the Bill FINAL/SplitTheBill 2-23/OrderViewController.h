//
//  OrderViewController.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Order.h"

@interface OrderViewController : UITableViewController<UITableViewDelegate> {

}
@property(nonatomic, retain) Order *currentOrder;

// index of the last group item found in the currentOrder.groupItems array
// reset for each person
@property(nonatomic, assign)int lastGroupItemFound;

-(void)addItemWithIndex:(int)personIndex;
-(float)calculatePersonTotal:(int)personIndex;

@end
