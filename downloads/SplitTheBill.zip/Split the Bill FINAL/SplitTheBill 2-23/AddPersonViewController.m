//
//  AddPersonViewController.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddPersonViewController.h"
#import "NewOrderViewController.h"
#import "Person.h"

@implementation AddPersonViewController
@synthesize newOrderVC, nameTextField, savedGuestsToAdd;

#pragma mark -
#pragma mark Helper methods
-(void)addPerson {
	// pass the person we made back to new order's order
	// Also add to the userDefaults if this is a new name and save back to the defaults
	if (nameTextField.text.length > 0) {
		//They have entered a new person's name, add him/her to our order
		Person *newPerson = [[Person alloc] initWithName:nameTextField.text];
		[newOrderVC.currentOrder.people addObject:newPerson];
		
		//Update our user defaults if this is a new person
		NSMutableArray *array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"savedPeople"]];
		if(![array containsObject:newPerson.name]){
			[array addObject:newPerson.name];
		}
		[[NSUserDefaults standardUserDefaults] setObject:array forKey:@"savedPeople"];
		[newPerson release];
		
	}
	
	
	//Check to see if they've selected savedpeople
	if([savedGuestsToAdd count] > 0) {
		BOOL canAdd = YES;
		for (NSString *name in savedGuestsToAdd) {
			Person *tempPerson = [[Person alloc] initWithName:name];
			//checks to see if the people selected have already been added to the current order, if they have it doesnt add them
			for(Person *peep in newOrderVC.currentOrder.people){
				if(peep.name == name){
					canAdd = NO;
					//NSLog(@"this person is already in here");
				}
			}
			//NSLog(@" person we are trying to add: %@", tempPerson);
			if(canAdd == YES){
				[newOrderVC.currentOrder.people addObject:tempPerson];
			}
			//NSLog(@" current people on order: %@", newOrderVC.currentOrder.people);
			
			[tempPerson release];
		}
	}
	
	
	[self.navigationController popViewControllerAnimated:YES];
	
}

#pragma mark -
#pragma mark Initialization

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];
	self.navigationItem.title = @"Add Guests";
	savedGuestsToAdd = [[NSMutableArray alloc] init];
	//nameTextField.delegate = self;
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections. If there are no old users stored in the defaults, 2 sections, otherwise 3.
	NSMutableArray *array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"savedPeople"]];
	if([array count] == 0){
		return 2;
	}else{
		return 4;
	}
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
	if(section != 2){
		return 1;
	}else{
		NSMutableArray *array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"savedPeople"]];
		return [array count];
	}
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
    static NSString *CellTextIndentifier = @"CellText";
	
	UITableViewCell *cell;
	UITextField *textField;
	
	if((indexPath.section == 0) && (indexPath.row == 0)) {
		//Guest name input
		cell = [tableView dequeueReusableCellWithIdentifier:CellTextIndentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellTextIndentifier] autorelease];
			textField = [[UITextField alloc] initWithFrame:CGRectMake(20,10,265,30)];
			textField.textAlignment = UITextAlignmentLeft;
			textField.returnKeyType = UIReturnKeyDone;
			textField.delegate = self;
			textField.tag = 1;
			[cell addSubview:textField];
			[textField release];
		}
	}
	else {
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		}
	}
	
	//cell.selectionStyle = UITableViewCellSelectionStyleNone; // don't make it highlight in blue
	
	if((indexPath.section == 0) && (indexPath.row == 0)) {
		UITextField *nameField = (UITextField *)[cell viewWithTag:1];
		nameField.placeholder = @"Name of Guest";
		nameField.returnKeyType = UIReturnKeyDone;
		nameField.autocapitalizationType = UITextAutocapitalizationTypeWords;
		nameField.textAlignment = UITextAlignmentLeft;
		nameField.clearButtonMode = UITextFieldViewModeUnlessEditing;
		nameField.delegate = self;
		nameTextField = nameField;
	} 
	else if ((indexPath.section == 1) && (indexPath.row == 0)) {
		cell.textLabel.textAlignment = UITextAlignmentCenter;
		cell.textLabel.text = @"Add Guest(s)";
	}
	else if(indexPath.section == 2){
		NSMutableArray *array = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"savedPeople"]];
		cell.textLabel.text = [array objectAtIndex:indexPath.row];
		//if the save person being loaded was added already add a checkmark to it
		for(Person *peep in newOrderVC.currentOrder.people){
			if(peep.name == [array objectAtIndex:indexPath.row]){
				cell.accessoryType = UITableViewCellAccessoryCheckmark;
			}
		}
	} else if (indexPath.section == 3) {
		cell.textLabel.textAlignment = UITextAlignmentCenter;
		cell.textLabel.text = @"Clear All Saved Guest(s)";
	}
	
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[nameTextField resignFirstResponder];
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	if(((indexPath.section == 1) && (indexPath.row == 0)) && ((nameTextField.text.length > 0) || ([savedGuestsToAdd count] > 0))) {
		//Add guest button tapped, and either they've entered text for the name field or they've checked off one of the savedPeople
		[self addPerson];
	}
	else if (indexPath.section == 2) {
		//Guests from memory tapped
		UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
		if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
			cell.accessoryType = UITableViewCellAccessoryNone;
			//Remove it from our array of savedGuestsToAdd
			[savedGuestsToAdd removeObject:cell.textLabel.text];
		} else {
			cell.accessoryType = UITableViewCellAccessoryCheckmark;
			//Add to our array
			[savedGuestsToAdd addObject:cell.textLabel.text];
		}
		//NSLog(@"savedGuestsToAdd: %@", savedGuestsToAdd);
		//[cell release];
	} else if (indexPath.section == 3) {
		[savedGuestsToAdd removeAllObjects];
		
		NSMutableArray *array = [[NSMutableArray alloc] init];
		[[NSUserDefaults standardUserDefaults] setObject:array forKey:@"savedPeople"];
		[array release];
		[tableView reloadData];
	}
}

#pragma mark -
#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[nameTextField resignFirstResponder];
	[self addPerson];
	return YES;
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
	[savedGuestsToAdd release];
    [super dealloc];
}


@end

