//
//  AddGroupItemViewController.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"
#import "Item.h"
#import "Order.h"

@interface AddGroupItemViewController : UITableViewController <UITextFieldDelegate> {

}

@property (nonatomic, retain)NSMutableArray *allPeople;
@property(nonatomic,retain)UITextField *nameTextField;
@property(nonatomic, retain)UITableViewCell *nameTFCell;
@property(nonatomic,retain)UITextField *priceTextField;
@property(nonatomic, retain)UITableViewCell *selectedCell;
@property(nonatomic, retain)NSMutableArray *selectedPeople;
@property(nonatomic, retain)Order *myOrder;

-(void)addItem;
-(void)priceKeyboardShouldReturn;

@end
