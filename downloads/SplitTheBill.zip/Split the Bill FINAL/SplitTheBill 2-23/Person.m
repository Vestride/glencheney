//
//  Person.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Person.h"
#import "Item.h"


@implementation Person
@synthesize name, items, subtotal, total, tip, tax;


- (id)initWithName:(NSString *)personName {
	self = [super init];
	if(!self) return nil;
	
	self.name = personName;
	self.items = [[NSMutableArray alloc] init];
	self.subtotal = 0;
	self.total = 0;
	self.tip = 0;
	self.tax = 0;
	
	return self;
}

- (void)addItem:(Item *)newItem {
	[items addObject:newItem];
}

//Might need to remove by index...
- (void)removeItem:(Item *)item {
	[items removeObject:item];
}

- (NSString *)description {
	return [NSString stringWithFormat:@"Name: %@, Items: %@, subtotal: %f, tax: %f, tip: %f, total: %f, ", name, items, subtotal, tax, tip, total];
}

- (void) dealloc
{
	[name release];
	[items release];
	[super dealloc];
}


@end
