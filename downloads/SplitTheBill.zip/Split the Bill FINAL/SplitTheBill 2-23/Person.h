//
//  Person.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Item.h"
#import "GroupItem.h"

@interface Person : NSObject {

}

@property(nonatomic, retain)NSMutableArray *items;
@property(nonatomic, copy)NSString *name;
@property(nonatomic, assign)float subtotal;
@property(nonatomic, assign)float total;
@property(nonatomic, assign)float tip;
@property(nonatomic, assign)float tax;

- (id)initWithName:(NSString *)personName;
- (void)addItem:(Item *)newItem;
- (void)removeItem:(Item *)item;

@end
