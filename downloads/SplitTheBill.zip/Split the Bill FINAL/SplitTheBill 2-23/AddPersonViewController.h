//
//  AddPersonViewController.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewOrderViewController.h"

@interface AddPersonViewController : UITableViewController <UITextFieldDelegate> {

}

@property(nonatomic, retain)NewOrderViewController *newOrderVC;
@property(nonatomic, retain)UITextField *nameTextField;
@property(nonatomic, retain)NSMutableArray *savedGuestsToAdd;

@end
