//
//  ChecksViewController.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ChecksViewController.h"
#import "PersonalCheckViewController.h"

@implementation ChecksViewController
@synthesize currentOrder;

#pragma mark Helper methods

//Calculate, set, and return the tip for each person
- (float)calculatePersonalTip:(Person *)currentPerson {
	float tip = (currentOrder.tip / [currentOrder.people count]);
	currentPerson.tip = tip;
	return tip;
}

//Calculate, set, and return the tax for each person
- (float)calculatePersonalTax:(Person *)currentPerson {
	float tax = (currentOrder.tax / [currentOrder.people count]);
	currentPerson.tax = tax;
	return tax;
}

//Calculate, set, and return the total for each person
- (float)calculatePersonalTotal:(Person *)currentPerson {
	float tax = [self calculatePersonalTax:currentPerson];
	float tip = [self calculatePersonalTip:currentPerson];
	currentPerson.total = currentPerson.subtotal + tax + tip;
	return currentPerson.total;
}

- (void)personalDetails:(Person *)currentPerson groupItems:(NSMutableArray *)groupItems {
	PersonalCheckViewController *detailViewController = [[PersonalCheckViewController alloc] initWithStyle:UITableViewStyleGrouped];
	
	//Pass it the currently selected person
	detailViewController.person = currentPerson;
	detailViewController.groupItems = groupItems;
	
	// Pass the selected object to the new view controller.
	[self.navigationController pushViewController:detailViewController animated:YES];
	[detailViewController release];
}
#pragma mark -

#pragma mark -
#pragma mark Initialization


- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization.
		self.navigationItem.title = @"Checks";
    }
    return self;
}



#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];

	for (Person *currentPerson in currentOrder.people) {
		[self calculatePersonalTotal:currentPerson];
	}
	
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 2;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section (Number of guests)
	if (section == 0) {
		return [[currentOrder people] count];
	}
	else {
		return 1;
	}
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"CellPerson";
	static NSString *CellFinished = @"CellFinished";
    
	UITableViewCell *cell;
	
	if (indexPath.section == 0) {
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
		}
	}
	else {
		cell = [tableView dequeueReusableCellWithIdentifier:CellFinished];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellFinished] autorelease];
		}
	}
    
    
    // People
	if (indexPath.section == 0) {
		cell.textLabel.text = [[[currentOrder people] objectAtIndex:indexPath.row] name];
		float total = [[currentOrder.people objectAtIndex:indexPath.row] total];
		cell.detailTextLabel.text = [NSString stringWithFormat:@"$%.2f", total];
		cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
	}
	// Finished Button
	else {
		cell.textLabel.text = @"Finished";
		cell.textLabel.textAlignment = UITextAlignmentCenter;
	}

	    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
	if (indexPath.section == 0) {
		[self personalDetails:[currentOrder.people objectAtIndex:indexPath.row] groupItems:currentOrder.groupItems];
	}
	else {
		//Save off current order
		/*NSMutableArray *pastOrders = [NSMutableArray arrayWithArray:[[NSUserDefaults standardUserDefaults] arrayForKey:@"orders"]];
		if(![pastOrders containsObject:currentOrder.timestamp]){
			[pastOrders addObject:currentOrder];
		}
		[[NSUserDefaults standardUserDefaults] setObject:pastOrders forKey:@"orders"];
		*/
		
		//redirect
		[self.navigationController popToRootViewControllerAnimated:YES];
	}
}

- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath {
	[self personalDetails:[currentOrder.people objectAtIndex:indexPath.row] groupItems:currentOrder.groupItems];
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
	[currentOrder release];
    [super dealloc];
}


@end

