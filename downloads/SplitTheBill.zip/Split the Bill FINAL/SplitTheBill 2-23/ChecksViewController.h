//
//  ChecksViewController.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Order.h"
#import "Person.h"

@interface ChecksViewController : UITableViewController {

}

@property(nonatomic, retain)Order *currentOrder;

- (float)calculatePersonalTip:(Person *)currentPerson;
- (float)calculatePersonalTax:(Person *)currentPerson;
- (float)calculatePersonalTotal:(Person *)currentPerson;
- (void)personalDetails:(Person *)currentPerson groupItems:(NSMutableArray *)groupItems;

@end
