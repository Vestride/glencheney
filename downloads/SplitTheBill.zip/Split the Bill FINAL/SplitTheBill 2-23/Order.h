//
//  Order.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Order : NSObject {
	
}

@property(nonatomic, copy)NSString *timestamp;
@property(nonatomic, retain)NSMutableArray *people;
@property(nonatomic, retain)NSMutableArray *groupItems;
@property(nonatomic, assign)float subtotal;
@property(nonatomic, assign)float total;
@property(nonatomic, assign)float tax;
@property(nonatomic, assign)float tip;

@end
