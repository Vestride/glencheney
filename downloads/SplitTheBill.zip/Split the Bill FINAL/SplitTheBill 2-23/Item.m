//
//  Item.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Item.h"
#import "Person.h"

@implementation Item
@synthesize name, price, owner;

- (id)initWithName:(NSString *)itemName price:(float)itemPrice owner:(Person *)itemOwner {
	self = [super init];
	if(!self) return nil;
	
	int roundedItemPrice = itemPrice * 100;
	
	self.name = itemName;
	self.price = roundedItemPrice/100.0;
	self.owner = itemOwner;
	
	return self;
}

- (NSString *) description {
	return [NSString stringWithFormat:@"Name: %@, Price: %f", name, price];
}

- (void) dealloc
{
	[name release];
	[super dealloc];
}

@end
