//
//  AddItemViewController.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AddItemViewController.h"
#import "SlidingMessageViewController.h"

@implementation AddItemViewController
@synthesize nameTextField, nameTFCell, priceTextField, itemOwner, selectedCell;

#pragma mark -
#pragma mark Helper methods
-(void)addItem {
	NSLog(@"Add Item");
	
	NSString *selectedCellVal;
	if(selectedCell == nameTFCell) {
		selectedCellVal = nameTextField.text;
	} else {
		selectedCellVal = selectedCell.textLabel.text;
	}
	
	Item *addingItem = [[Item alloc] initWithName:selectedCellVal price:[priceTextField.text floatValue] owner:itemOwner];
	[itemOwner.items addObject:addingItem];
	
	[addingItem release];
	
	//[selectedCellVal release];
	
	[self.navigationController popViewControllerAnimated:YES];
}


- (BOOL)findAndResignFirstResponder: (UIView*) stView
{
	self.navigationItem.rightBarButtonItem = nil;
    if (stView.isFirstResponder) {
        [stView resignFirstResponder];
        return YES;     
    }
    for (UIView *subView in stView.subviews) {
        if ([self findAndResignFirstResponder: subView])
            return YES;
    }
    return NO;
}


#pragma mark -
#pragma mark Initialization

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];
	self.navigationItem.title = @"New Item";
}

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 3;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
	if(section == 0) {
		return 5;
	} else {
		return 1;
	}
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    static NSString *CellTextIndentifier = @"CellText";
	
	UITableViewCell *cell;
	UITextField *textField;
	
	if(((indexPath.section == 0) && (indexPath.row == 0)) || (indexPath.section == 1)) {
		//Name input or Price input
		cell = [tableView dequeueReusableCellWithIdentifier:CellTextIndentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellTextIndentifier] autorelease];
			textField = [[UITextField alloc] initWithFrame:CGRectMake(20,10,265,30)];
			textField.textAlignment = UITextAlignmentLeft;
			textField.returnKeyType = UIReturnKeyDone;
			textField.delegate = self;
			textField.tag = 1;
			[cell addSubview:textField];
			[textField release];
		}
	} else {
		//Appetizer, Drink, Entree, Dessert
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		}
	}
	
	//cell.selectionStyle = UITableViewCellSelectionStyleNone; // don't make it highlight in blue
	
	if(indexPath.section == 0) {
		//Item type
		if(indexPath.row == 0) {
			//Name of item
			UITextField *nameField = (UITextField *)[cell viewWithTag:1];
			nameField.placeholder = @"Name of Item";
			nameField.keyboardType = UIKeyboardTypeDefault;
			
			if(selectedCell == nil) {
				selectedCell = cell;
				cell.accessoryType = UITableViewCellAccessoryCheckmark;
				nameTFCell = cell;
			}
			//[nameTextField release];
			nameTFCell = cell;
			nameTextField = nameField;
		}
		else if (indexPath.row == 1) {
			cell.textLabel.text = @"Appetizer";
		} else if (indexPath.row == 2) {
			cell.textLabel.text = @"Drink";
		} else if (indexPath.row == 3) {
			cell.textLabel.text = @"Entree";
		} else if(indexPath.row == 4) {
			cell.textLabel.text = @"Dessert";
		}
	} else if(indexPath.section == 1) {
		//Price input
		UITextField *priceField = (UITextField *)[cell viewWithTag:1];
		priceField.placeholder = @"Price of Item";
		priceField.keyboardType = UIKeyboardTypeDefault;
		
		priceField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
		if ((UIKeyboardTypeDecimalPad) && ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 4.1)) {
			priceField.keyboardType = UIKeyboardTypeDecimalPad;
		}
		
		//[priceTextField release];
		priceTextField = priceField;
	} else {
		cell.textLabel.text = @"Add Item";
		cell.textLabel.textAlignment = UITextAlignmentCenter;
	}
	
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	[self findAndResignFirstResponder: self.view];
	if(indexPath.section == 0) {
		
		selectedCell.accessoryType = UITableViewCellAccessoryNone;
		
		UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
		cell.accessoryType = UITableViewCellAccessoryCheckmark;
		
		//[selectedCell release];
		selectedCell = cell;
		
	}
    if(indexPath.section == 2) {
		if(selectedCell == nameTFCell){
			if((nameTextField.text.length > 0) && (priceTextField.text.length > 0)) {
				[self addItem];
			} else {
				SlidingMessageViewController *slideVC = [[SlidingMessageViewController alloc] initWithTitle:@"Error" message:@"Enter the name or select an item"];
				[self.view addSubview:slideVC.view];
				[slideVC showMsgWithDelay:3];
				//releasing this vc here causes the app to crash
				//[slideVC release];
			}
		} else if(priceTextField.text.length > 0) {
			[self addItem];
		} else {
			SlidingMessageViewController *slideVC = [[SlidingMessageViewController alloc] initWithTitle:@"Error" message:@"You must enter a price"];
			[self.view addSubview:slideVC.view];
			[slideVC showMsgWithDelay:3];
			//releasing this vc here causes the app to crash
			//[slideVC release];
		}
	}
}


#pragma mark -
#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if(textField == nameTextField) {
		// check the cell with the textField in it.
		selectedCell.accessoryType = UITableViewCellAccessoryNone;
		nameTFCell.accessoryType = UITableViewCellAccessoryCheckmark;
		selectedCell = nameTFCell;
		
	}else if(textField == priceTextField){
		//if the numpad is going to appear, adds a done button to the nav bar to resign the keyboard
		//it's action calls a custom method that gets rid of the button and resigns the keyboard
		UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(priceKeyboardShouldReturn)];
		self.navigationItem.rightBarButtonItem = done;
	}
	return YES;
}
//this method is called by the done button added when the numpad keyboard appears, it removes the button, and resigns the keyboard
- (void)priceKeyboardShouldReturn{
	self.navigationItem.rightBarButtonItem = nil;
	[self.priceTextField becomeFirstResponder];
	[self.priceTextField resignFirstResponder];
}
#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
	//[nameTextField release];
	//[priceTextField release];
	//[selectedCell release];
	//[itemOwner release];
	//[nameTFCell release];
    [super dealloc];
}


@end

