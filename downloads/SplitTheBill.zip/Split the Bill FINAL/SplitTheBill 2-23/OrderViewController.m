//
//  OrderViewController.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "OrderViewController.h"
#import "AddItemViewController.h"
#import "AddGroupItemViewController.h"
#import "ReviewOrderViewController.h"
#import "Order.h"
#import "Item.h"
#import "GroupItem.h"
#import "Person.h"

//group item tag constant
#define REGULAR_ITEM -1

@implementation OrderViewController
@synthesize currentOrder, lastGroupItemFound;

#pragma mark -
#pragma mark Helper methods
-(void)addItem:(id)sender {
	NSInteger index = ((UIControl *)sender).tag;
	[self addItemWithIndex:index];
	
}

-(void)addItemWithIndex:(int)personIndex {
	NSLog(@"Add Item for %@", [[currentOrder.people objectAtIndex:personIndex] name]);
	AddItemViewController *detailViewController = [[AddItemViewController alloc] initWithStyle:UITableViewStyleGrouped];
	detailViewController.itemOwner = [currentOrder.people objectAtIndex:personIndex];
	[self.navigationController pushViewController:detailViewController animated:YES];
	[detailViewController release];
}

-(void)addGroupItem {
	NSLog(@"addGroupItem");
	AddGroupItemViewController *detailViewController = [[AddGroupItemViewController alloc] initWithStyle:UITableViewStyleGrouped];
	detailViewController.allPeople = currentOrder.people;
	detailViewController.myOrder = currentOrder;
	[self.navigationController pushViewController:detailViewController animated:YES];
	[detailViewController release];
}

-(void)reviewOrder {
	NSLog(@"Review Order");
	ReviewOrderViewController *detailViewController = [[ReviewOrderViewController alloc] initWithStyle:UITableViewStyleGrouped];
	detailViewController.currentOrder = self.currentOrder;
	[self.navigationController pushViewController:detailViewController animated:YES];
	[detailViewController release];
}

-(float)calculatePersonTotal:(int)personIndex {
	float total = 0;
	
	//Get the current person we're working with
	Person *currentPerson = [currentOrder.people objectAtIndex:personIndex];
	
	//Add their items
	for(Item *item in currentPerson.items) {
		total += item.price;
	}
	
	//Get the parts of the group items they own
	for (GroupItem *groupItem in currentOrder.groupItems) {
		for (Person *owner in groupItem.owners) {
			if (owner.name == currentPerson.name) {
				total += (groupItem.price / [groupItem.owners count]);
			}
		}
	}
	
	//Save it
	currentPerson.subtotal = total;
	
	NSLog(@"%@'s total: $%.2f", currentPerson.name, currentPerson.subtotal);
	
	return total;
}

#pragma mark -
#pragma mark Initialization

/*
- (id)initWithStyle:(UITableViewStyle)style {
    // Override initWithStyle: if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/


#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
	//NSLog(@"OrderVC currentOrder: %@", currentOrder);
    [super viewDidLoad];
	
	UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(reviewOrder)];
	self.navigationItem.rightBarButtonItem = done;
	[done release];
	
	self.navigationItem.title = @"Order";
	
	[self setEditing:YES];
	self.tableView.allowsSelectionDuringEditing = YES;
	lastGroupItemFound = -1;
}


/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
	[self.tableView reloadData];
}

/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return [currentOrder.people count]+1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section
	if(section == 0) {
		return 1 + [currentOrder.groupItems count];
	} else {
		
		int numGroupItems = 0;
		
		// how many group items does each person have?
		for(int i = 0; i < [currentOrder.groupItems count]; i++) {
			for(int j = 0; j < [[[currentOrder.groupItems objectAtIndex:i] owners] count]; j++) {
				if([[[[currentOrder.groupItems objectAtIndex:i] owners] objectAtIndex:j] name] == [[currentOrder.people objectAtIndex:(section-1)] name]) {
					numGroupItems ++;
				}
			}
		}
		
		return 1 + [[[currentOrder.people objectAtIndex:(section-1)] items] count] + numGroupItems;
	}
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
	static NSString *CellPersonHeaderIdentifier = @"CellPersonHeader";
	static NSString *CellGroupHeaderIdentifier = @"CellGroupHeader";
    
	UITableViewCell *cell;
	if(indexPath.row == 0) {
		if(indexPath.section == 0) {
			cell = [tableView dequeueReusableCellWithIdentifier:CellGroupHeaderIdentifier];
			if (cell == nil) {
				cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellGroupHeaderIdentifier] autorelease];
				
				UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
				[button addTarget:self action:@selector(addGroupItem) forControlEvents:UIControlEventTouchUpInside];
				cell.accessoryView = button;
				
			}
		} 
		else {
			cell = [tableView dequeueReusableCellWithIdentifier:CellPersonHeaderIdentifier];
			if (cell == nil) {
				cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellPersonHeaderIdentifier] autorelease];
				
				UIButton *button = [UIButton buttonWithType:UIButtonTypeContactAdd];
				[button addTarget:self action:@selector(addItem:) forControlEvents:UIControlEventTouchUpInside];
				button.tag = (indexPath.section - 1);
				cell.accessoryView = button;
				
			}
		}
	} 
	else {
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
			cell.accessoryView = nil;
		}
    }
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone; // don't make it highlight in blue
	cell.textLabel.textColor = [UIColor blackColor];
	cell.detailTextLabel.textColor = [UIColor blackColor];
	cell.textLabel.font = [UIFont systemFontOfSize:17.0];
	
    if(indexPath.section == 0) {  // Group Items Section
		if(indexPath.row == 0) { // Group Items Header / Add Group Item
			cell.textLabel.text = @"Group Items";
			cell.selectionStyle = UITableViewCellSelectionStyleBlue;
			
		} else { // List all Group Items
			GroupItem *currentItem = [currentOrder.groupItems objectAtIndex:(indexPath.row - 1)];
			cell.textLabel.text = [currentItem name];
			cell.textLabel.font = [UIFont systemFontOfSize:14.0];
			cell.detailTextLabel.text = [NSString stringWithFormat:@"$%.2f", [currentItem price]];
			cell.detailTextLabel.textColor = [UIColor blackColor];
		}
		
	} else if (indexPath.row == 0) { // Person Header
		
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
		
		lastGroupItemFound = -1; // reset this value for each person
		
		cell.textLabel.text = [[currentOrder.people objectAtIndex:(indexPath.section - 1)] name];
		
		float total = [self calculatePersonTotal:(indexPath.section - 1)];
		
		cell.detailTextLabel.text = [NSString stringWithFormat:@"$%.2f", total];
		
	} else if([[[currentOrder.people objectAtIndex:(indexPath.section - 1)] items] count] > (indexPath.row - 1)) {  // Person's Items
		Item *currentItem = [[[currentOrder.people objectAtIndex:(indexPath.section - 1)] items] objectAtIndex:(indexPath.row - 1)];
		cell.textLabel.text = [currentItem name];
		cell.textLabel.font = [UIFont systemFontOfSize:14.0];
		cell.detailTextLabel.text = [NSString stringWithFormat:@"$%.2f", [currentItem price]];
		cell.detailTextLabel.textColor = [UIColor blackColor];
		cell.tag = REGULAR_ITEM;
		
	} else { // Person's Group Items
		
		BOOL foundItem = NO;
		
		for(int i = 0; i < [currentOrder.groupItems count]; i++) { // loop through all group items
			for(int j = 0; j < [[[currentOrder.groupItems objectAtIndex:i] owners] count]; j++) { // loop through the owners of the item
				
				if([[[[currentOrder.groupItems objectAtIndex:i] owners] objectAtIndex:j] name] == [[currentOrder.people objectAtIndex:(indexPath.section-1)] name]) {
					// owner name matches current person's name
					
					// don't add it if you've already added it
					if(lastGroupItemFound < i) {
						
						cell.textLabel.text = [[currentOrder.groupItems objectAtIndex:i] name];
						cell.textLabel.font = [UIFont systemFontOfSize:14.0];
						cell.detailTextLabel.text = [NSString stringWithFormat:@"$%.2f", ([[currentOrder.groupItems objectAtIndex:i] price]/[[[currentOrder.groupItems objectAtIndex:i] owners] count])];
						cell.textLabel.textColor = [UIColor grayColor];
						cell.detailTextLabel.textColor = [UIColor grayColor];
						cell.tag = i;
						
						lastGroupItemFound = i;
						foundItem = YES;
					}
					
					break; // found the owner, don't need to keep looking
				}
			}
			
			if(foundItem){
				break;
			}
		}
	}
    
    return cell;
}



// Conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
	if(indexPath.row == 0) {
		return NO;
	} else {
		return YES;
	}
}

// Editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
		UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
		//NSLog(@"Cell detailtext: %@", cell.detailTextLabel.text);
				
		if (cell.tag == REGULAR_ITEM) {
			Person *curPerson = [currentOrder.people objectAtIndex:(indexPath.section - 1)];
			[curPerson.items removeObjectAtIndex:(indexPath.row - 1)];
			
			[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
		}
		else if (indexPath.section == 0) {
			//If we're deleting from the actual group item
			//delete it from everything
			[currentOrder.groupItems removeObjectAtIndex:cell.tag];
		}
		else {
			//remove the person from the group item
			GroupItem *groupItem = [currentOrder.groupItems objectAtIndex:cell.tag];
			Person *currentPerson = [currentOrder.people objectAtIndex:(indexPath.section-1)];
			for (Person *owner in groupItem.owners) {
				if (owner.name == currentPerson.name) {
					[groupItem.owners removeObject:owner];
					break;
				}
			}
			if ([groupItem.owners count] < 1) {
				//No one owns this item anymore, delete it
				[currentOrder.groupItems removeObjectAtIndex:cell.tag];
			}
		}
        
		
		[tableView reloadData];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}



/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if(indexPath.row == 0) { // Clicked a header
		if(indexPath.section == 0) { // Clicked "group items"
			[self addGroupItem];
		} else { // Clicked a "person item"
			[self addItemWithIndex:(indexPath.section - 1)];
		}
	}
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
	[currentOrder release];
    [super dealloc];
}


@end

