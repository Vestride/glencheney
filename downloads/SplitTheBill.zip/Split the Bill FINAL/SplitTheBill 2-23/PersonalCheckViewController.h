//
//  PersonalCheckViewController.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"

@interface PersonalCheckViewController : UITableViewController {
	
}

@property(nonatomic, retain)Person *person;
@property(nonatomic, retain)NSMutableArray *groupItems;
@property(nonatomic, assign)int numItems;
@property(nonatomic, retain)NSMutableArray *myItems;
@property(nonatomic, retain)NSMutableArray *myCosts;

@end
