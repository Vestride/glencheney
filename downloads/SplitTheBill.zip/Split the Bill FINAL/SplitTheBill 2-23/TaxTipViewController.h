//
//  TaxTipViewController.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Order.h"

@interface TaxTipViewController : UIViewController<UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate> {
	IBOutlet UIPickerView *pickerView;
	IBOutlet UILabel *subtotalLabel;
	IBOutlet UILabel *totalLabel;
}

@property(nonatomic, retain)Order *currentOrder;
@property(nonatomic, retain)NSMutableArray *tipDisplays;
@property(nonatomic, retain)NSMutableArray *tipValues;
@property(nonatomic, assign)float total;
@property(nonatomic, assign)float tax;
@property(nonatomic, assign)float tip;
@property(nonatomic, retain)IBOutlet UITextField *taxTextField;

-(NSMutableArray *)getTipArrays;
-(NSMutableArray *)makeTipArrays;
-(float)calculateTotal:(float)tipPercent;
-(void)taxKeyboardShouldReturn;
-(IBAction)splitChecks;

@end
