//
//  PersonalCheckViewController.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PersonalCheckViewController.h"
#import "Item.h"
#import "GroupItem.h"

@implementation PersonalCheckViewController
@synthesize person, groupItems, myItems, myCosts, numItems;

#pragma mark -
#pragma mark Initialization

/*
- (id)initWithStyle:(UITableViewStyle)style {
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization.
		
    }
    return self;
}
*/

#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];

	self.navigationItem.title = person.name;
	NSLog(@"Person: %@", person);
	
	
	myItems = [[NSMutableArray alloc] init];
	myCosts = [[NSMutableArray alloc] init];
	for (Item *item in person.items) {
		[myItems addObject:item.name];
		[myCosts addObject:[NSNumber numberWithFloat:item.price]];
	}
	
	for (GroupItem *groupItem in groupItems) {
		for (Person *owner in groupItem.owners) {
			if (owner.name == person.name) {
				float itemPrice = (groupItem.price / [groupItem.owners count]);
				[myItems addObject:groupItem.name];
				[myCosts addObject:[NSNumber numberWithFloat:itemPrice]];
			}
		}
	}
	
	numItems = [myItems count];
	
	NSLog(@"number of items for %@: %d", person.name, numItems);
	NSLog(@"my items %@, my costs %@", myItems, myCosts);
	
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

/*
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
*/
/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return (numItems + 3);
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"CellDetailed";
	static NSString *CellRight = @"CellRight";
    
	UITableViewCell *cell;
	if (indexPath.row < numItems) {
		cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
		}
	}
	else {
		cell = [tableView dequeueReusableCellWithIdentifier:CellRight];
		if (cell == nil) {
			cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellRight] autorelease];
		}
	}
    
    // Configure the cell
	if (indexPath.row < numItems) {
		cell.textLabel.text = [myItems objectAtIndex:indexPath.row];
		cell.detailTextLabel.text = [NSString stringWithFormat:@"$%.2f", [[myCosts objectAtIndex:indexPath.row] floatValue]];
	}
	else if (indexPath.row == numItems){
		cell.textLabel.text = [NSString stringWithFormat:@"tax: $%.2f", person.tax];
		cell.textLabel.textAlignment = UITextAlignmentRight;
	}
	else if (indexPath.row == (numItems + 1)){
		cell.textLabel.text = [NSString stringWithFormat:@"tip: $%.2f", person.tip];
		cell.textLabel.textAlignment = UITextAlignmentRight;
	}
	else if (indexPath.row == (numItems + 2)){
		cell.textLabel.text = [NSString stringWithFormat:@"total: $%.2f", person.total];
		cell.textLabel.textAlignment = UITextAlignmentRight;
	}
						  
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source.
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
    }   
}
*/


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/


/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic may go here. Create and push another view controller.
    /*
    <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController release];
    */
}


#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

