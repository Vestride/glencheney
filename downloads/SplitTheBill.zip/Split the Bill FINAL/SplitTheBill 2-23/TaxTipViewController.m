//
//  TaxTipViewController.m
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TaxTipViewController.h"
#import "ChecksViewController.h"

@implementation TaxTipViewController
@synthesize currentOrder, tipDisplays, tipValues, total, taxTextField, tax, tip;

#pragma mark Helper methods 

- (NSMutableArray *)getTipArrays {
	NSMutableArray *tipArrays;
	if ([[NSUserDefaults standardUserDefaults] objectForKey:@"tipArrays"] == nil) {
		//doesn't exist. create it.
		tipArrays = [self makeTipArrays];
		[[NSUserDefaults standardUserDefaults] setObject:tipArrays forKey:@"tipArrays"];
	} else {
		//already exists, grab it
		tipArrays = [[NSUserDefaults standardUserDefaults] objectForKey:@"tipArrays"];
	}
	return tipArrays;
}

- (NSMutableArray *)makeTipArrays {
	//Create two empty arrays
	NSMutableArray *displays = [[NSMutableArray alloc] init];
	NSMutableArray *values = [[NSMutableArray alloc] init];
	
	//Put the values 1% - 99% and .01 - .99 in displays and values, respectively
	for (int i = 1; i < 100; i++) {
		[displays addObject:[NSString stringWithFormat:@"%d%%", i]]; //for a % character, you must escape it with %
		double onehundred = 100; //Make 100 a double, otherwise we don't get decimals... we get 0 when we divide
		float percent = i/onehundred;
		[values addObject:[NSNumber numberWithFloat:percent]];
	}
	
	//Combine to one array
	NSMutableArray *tipArrays = [[[NSMutableArray alloc] initWithObjects: displays, values, nil] autorelease];
	
	//Be a good person
	[displays release];
	[values release];
	
	return tipArrays;
}

- (float)calculateTotal:(float)tipPercent {
	//total = subtotal + tax + ((subtotal + tax) * tipPercent)
	tax = [taxTextField.text floatValue];
	tip = (currentOrder.subtotal + tax) * tipPercent;
	return currentOrder.subtotal + tax + tip;
}

- (IBAction)splitChecks {
	//Set total, tax, and tip properties for the Order
	total = [self calculateTotal:[[tipValues objectAtIndex:[pickerView selectedRowInComponent:0]] floatValue]];
	currentOrder.total = total;
	currentOrder.tax = tax;
	currentOrder.tip = tip;
	
	//Create the check view controller
	ChecksViewController *detailViewController = [[ChecksViewController alloc] initWithStyle:UITableViewStyleGrouped];
	
	//Pass along the order
	detailViewController.currentOrder = currentOrder;
	
	// Pass the selected object to the new view controller.
	[self.navigationController pushViewController:detailViewController animated:YES];
	[detailViewController release];
}

#pragma mark -

#pragma mark UIPickerViewDelegate methods

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
	return [tipDisplays objectAtIndex:row];
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
	NSLog(@"You selected row %d", row);
	float percent = [[tipValues objectAtIndex:row] floatValue];
	total = [self calculateTotal:percent];
	NSLog(@"total: %f", total);
	totalLabel.text = [NSString stringWithFormat:@"$%.2f",  total];
}
#pragma mark -

#pragma mark UIPickerViewDataSource methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
	//we only have one column;
	
	return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {	
	return [tipDisplays count];
}
#pragma mark -

#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}

//adds a done button to the nav bar to resign the keyboard
//its action calls a custom method that gets rid of the button and resigns the keyboard
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(taxKeyboardShouldReturn)];
	self.navigationItem.rightBarButtonItem = done;
	[done release];
	return YES;
}
//this method is called by the done button added when the numpad keyboard appears, it removes the button, and resigns the keyboard
- (void)taxKeyboardShouldReturn{
	self.navigationItem.rightBarButtonItem = nil;
	[self.taxTextField becomeFirstResponder];
	[self.taxTextField resignFirstResponder];
	
	//Update the total label on so the user does not have to move the picker
	total = [self calculateTotal:[[tipValues objectAtIndex:[pickerView selectedRowInComponent:0]] floatValue]];
	totalLabel.text = [NSString stringWithFormat:@"$%.2f",  total];
}
#pragma mark -

#pragma mark initialization
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
		self.navigationItem.title = @"Tax & Tip";
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
	
	//Reset user defaults for debugging
	//[[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"tipArrays"];
	
	//Set the subtotal text
	subtotalLabel.text = [NSString stringWithFormat:@"$%.2f", currentOrder.subtotal];
	
	//Get tip arrays and initialize them
	NSMutableArray *tipArrays = [NSMutableArray arrayWithArray:[self getTipArrays]];
	tipDisplays = [[NSMutableArray alloc] initWithArray:[tipArrays objectAtIndex:0]];
	tipValues = [[NSMutableArray alloc] initWithArray:[tipArrays objectAtIndex:1]];
	
	//Update the total label on load
	int row = [[NSUserDefaults standardUserDefaults] integerForKey:@"selectedTip"];
	float percent = [[tipValues objectAtIndex:row] floatValue];
	total = [self calculateTotal:percent];
	totalLabel.text = [NSString stringWithFormat:@"$%.2f",  total];
	
	//Change the keyboard if capable
	taxTextField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
	if ((UIKeyboardTypeDecimalPad) && ([[[UIDevice currentDevice] systemVersion] doubleValue] >= 4.1)) {
		taxTextField.keyboardType = UIKeyboardTypeDecimalPad;
	}
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	
	//Save the current row in the picker
	int row = [pickerView selectedRowInComponent:0];
	[[NSUserDefaults standardUserDefaults] setInteger:row forKey:@"selectedTip"];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	
	//Set the current row in the picker
	int row = [[NSUserDefaults standardUserDefaults] integerForKey:@"selectedTip"];
	[pickerView selectRow:row inComponent:0 animated:YES];
}
#pragma mark -

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
	[totalLabel release];
	[subtotalLabel release];
	[pickerView release];
	[taxTextField release];
	[tipDisplays release];
	[tipValues release];
	[currentOrder release];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
