//
//  GroupItem.h
//  SplitTheBill
//
//  Created by Allison N Carnwath on 2/7/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GroupItem : NSObject {

}

@property (nonatomic, copy)NSString *name;
@property (nonatomic, assign)float price;
@property (nonatomic, retain)NSMutableArray *owners;

- (id)initWithName:(NSString *)itemName price:(float)itemPrice owners:(NSMutableArray *)itemOwners;

@end
